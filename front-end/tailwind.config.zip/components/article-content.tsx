"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Clock,
  Calendar,
  User,
  Share2,
  BookOpen,
  ArrowRight,
  Check,
} from "lucide-react";
import { motion } from "framer-motion";

interface Article {
  id: number;
  title: string;
  excerpt: string;
  content: string;
  image: string;
  date: string;
  category: string;
  author: string;
}

interface ArticleContentProps {
  article: Article;
  readingTime: number;
  relatedArticles: Article[];
}

export function ArticleContent({
  article,
  readingTime,
  relatedArticles,
}: ArticleContentProps) {
  const [copied, setCopied] = useState(false);

  const handleShare = async () => {
    const url = window.location.href;

    if (navigator.share) {
      try {
        await navigator.share({
          title: article.title,
          text: article.excerpt,
          url: url,
        });
      } catch (error) {
        console.log("Error sharing:", error);
      }
    } else {
      // Fallback: copy to clipboard
      try {
        await navigator.clipboard.writeText(url);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (error) {
        console.log("Error copying to clipboard:", error);
      }
    }
  };

  // Format content dengan markdown sederhana
  const formatContent = (content: string) => {
    return content
      .split("\n")
      .map((paragraph, index) => {
        if (paragraph.trim() === "") return null;

        // Headers
        if (paragraph.startsWith("# ")) {
          return (
            <h1
              key={index}
              className="text-3xl font-bold mb-6 text-gray-900 mt-8"
            >
              {paragraph.replace("# ", "")}
            </h1>
          );
        }
        if (paragraph.startsWith("## ")) {
          return (
            <h2
              key={index}
              className="text-2xl font-bold mb-4 text-gray-900 mt-6"
            >
              {paragraph.replace("## ", "")}
            </h2>
          );
        }
        if (paragraph.startsWith("### ")) {
          return (
            <h3
              key={index}
              className="text-xl font-semibold mb-3 text-gray-800 mt-4"
            >
              {paragraph.replace("### ", "")}
            </h3>
          );
        }
        if (paragraph.startsWith("#### ")) {
          return (
            <h4
              key={index}
              className="text-lg font-semibold mb-2 text-gray-800 mt-3"
            >
              {paragraph.replace("#### ", "")}
            </h4>
          );
        }

        // Lists
        if (paragraph.startsWith("- ")) {
          return (
            <li key={index} className="ml-4 mb-2 text-gray-700 leading-relaxed">
              {paragraph.replace("- ", "")}
            </li>
          );
        }

        // Bold text
        const formattedText = paragraph.replace(
          /\*\*(.*?)\*\*/g,
          "<strong>$1</strong>"
        );

        // Regular paragraphs
        return (
          <p
            key={index}
            className="mb-4 text-gray-700 leading-relaxed text-justify"
            dangerouslySetInnerHTML={{ __html: formattedText }}
          />
        );
      })
      .filter(Boolean);
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Article Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8"
      >
        <div className="flex flex-wrap items-center gap-3 mb-4">
          <Badge className="bg-secondary hover:bg-[#2A6CB0] text-white px-3 py-1 rounded-full">
            {article.category}
          </Badge>
          <div className="flex items-center text-sm text-gray-500 gap-4">
            <span className="flex items-center gap-1">
              <Calendar className="h-4 w-4" />
              {article.date}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              {readingTime} menit baca
            </span>
            <span className="flex items-center gap-1">
              <User className="h-4 w-4" />
              {article.author}
            </span>
          </div>
        </div>

        <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 text-gray-900 leading-tight">
          {article.title}
        </h1>

        <p className="text-lg md:text-xl text-gray-600 mb-6 leading-relaxed">
          {article.excerpt}
        </p>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-secondary" />
            <span className="text-sm font-medium text-gray-700">
              Artikel Edukasi Stunting
            </span>
          </div>
          <Button
            onClick={handleShare}
            variant="outline"
            size="sm"
            className="flex items-center gap-2 rounded-full border-secondary text-secondary hover:bg-secondary hover:text-white"
          >
            {copied ? (
              <>
                <Check className="h-4 w-4" />
                Tersalin
              </>
            ) : (
              <>
                <Share2 className="h-4 w-4" />
                Bagikan
              </>
            )}
          </Button>
        </div>
      </motion.div>

      {/* Featured Image */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="relative h-64 md:h-96 w-full mb-8 rounded-xl overflow-hidden shadow-lg"
      >
        <Image
          src={article.image || "/placeholder.svg?height=600&width=800"}
          alt={article.title}
          fill
          className="object-cover"
        />
      </motion.div>

      {/* Article Content */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
        className="prose prose-lg max-w-none mb-12"
      >
        <div className="bg-white rounded-xl p-6 md:p-8 shadow-sm border border-gray-100">
          <div className="article-content">
            {formatContent(article.content)}
          </div>
        </div>
      </motion.div>

      {/* Related Articles */}
      {relatedArticles.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="mt-12"
        >
          <Separator className="mb-8" />
          <div className="flex items-center gap-3 mb-6">
            <BookOpen className="h-6 w-6 text-secondary" />
            <h2 className="text-2xl font-bold text-gray-900">
              Artikel Terkait
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {relatedArticles.map((relatedArticle, index) => (
              <motion.div
                key={relatedArticle.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.7 + index * 0.1 }}
              >
                <Link
                  href={`/edukasi/${relatedArticle.id}`}
                  className="block group"
                >
                  <Card className="overflow-hidden h-full border-0 shadow-sm hover:shadow-lg transition-all duration-300 rounded-lg">
                    <div className="relative h-48 w-full overflow-hidden">
                      <Image
                        src={
                          relatedArticle.image ||
                          "/placeholder.svg?height=300&width=400"
                        }
                        alt={relatedArticle.title}
                        fill
                        className="object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                      <div className="absolute top-3 left-3">
                        <Badge className="bg-secondary hover:bg-[#2A6CB0] text-white px-3 py-1 rounded-full">
                          {relatedArticle.category}
                        </Badge>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <div className="flex items-center text-sm text-gray-500 mb-2">
                        <Calendar className="h-4 w-4 mr-1" />
                        <span>{relatedArticle.date}</span>
                      </div>
                      <h3 className="text-lg font-bold mb-2 text-gray-900 line-clamp-2 group-hover:text-secondary transition-colors">
                        {relatedArticle.title}
                      </h3>
                      <p className="text-gray-600 text-sm line-clamp-2 mb-3">
                        {relatedArticle.excerpt}
                      </p>
                      <div className="flex items-center text-secondary font-medium text-sm group-hover:gap-2 transition-all">
                        <span>Baca Selengkapnya</span>
                        <ArrowRight className="h-4 w-4 ml-1 transition-transform group-hover:translate-x-1" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Call to Action */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.8 }}
        className="mt-12 bg-gradient-to-r from-secondary to-[#64B5F6] rounded-xl p-6 md:p-8 text-center text-white"
      >
        <h3 className="text-2xl font-bold mb-4">
          Ingin Tahu Lebih Banyak tentang Stunting?
        </h3>
        <p className="text-lg opacity-90 mb-6">
          Jelajahi artikel edukasi lainnya untuk mendapatkan informasi lengkap
          tentang pencegahan stunting
        </p>
        <Link href="/edukasi">
          <Button className="bg-white text-secondary hover:bg-gray-100 rounded-full px-8 py-3 font-semibold">
            Lihat Semua Artikel
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </Link>
      </motion.div>
    </div>
  );
}
