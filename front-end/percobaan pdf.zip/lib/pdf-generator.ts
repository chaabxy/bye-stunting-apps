import type { PredictionResult } from "@/app/(user)/cek-stunting/page";

import html2pdf from "html2pdf.js";

export interface ChildData {
  nama: string;
  namaIbu: string;
  tanggalLahir: Date;
  usia: number;
  jenisKelamin: string;
  beratBadan: number;
  tinggiBadan: number;
  alamat: {
    provinsi: string;
    kabupaten: string;
    kecamatan: string;
    desa: string;
  };
}

// export interface PredictionResult {
//   status: "normal" | "berisiko" | "stunting";
//   score: number; // persentase risiko
//   message: string;
//   recommendations: string[];
//   recommendedArticles: { title: string; category: string }[];
// }

// Fungsi untuk menghasilkan HTML konten laporan
export function generatePdfContent(
  childData: ChildData,
  result: PredictionResult
): string {
  const today = new Date().toLocaleDateString("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const tanggalLahir = childData.tanggalLahir.toLocaleDateString("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const statusColor =
    result.status === "normal"
      ? "#22c55e"
      : result.status === "berisiko"
      ? "#eab308"
      : "#ef4444";

  const statusText =
    result.status === "normal"
      ? "Normal"
      : result.status === "berisiko"
      ? "Berisiko Stunting"
      : "Stunting";

  return `
    <div class="container" style="max-width: 800px; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif; color: #333;">
      <div class="header" style="text-align: center; margin-bottom: 30px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">
        <div class="logo" style="font-size: 24px; font-weight: bold; color: #3b82f6;">ByeStunting</div>
        <div class="title" style="font-size: 20px; margin: 10px 0;">Laporan Pemeriksaan Stunting</div>
        <div class="date" style="font-size: 14px; color: #666;">Tanggal Pemeriksaan: ${today}</div>
      </div>
      
      <div class="section" style="margin-bottom: 20px;">
        <div class="section-title" style="font-size: 18px; font-weight: bold; margin-bottom: 10px; color: #3b82f6;">Data Anak</div>
        <table class="data-table" style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
          <tr>
            <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold; width: 40%;">Nama Anak</td>
            <td style="padding: 8px; border-bottom: 1px solid #ddd;">${
              childData.nama
            }</td>
          </tr>
          <tr>
            <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Nama Ibu Kandung</td>
            <td style="padding: 8px; border-bottom: 1px solid #ddd;">${
              childData.namaIbu
            }</td>
          </tr>
          <tr>
            <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Tanggal Lahir</td>
            <td style="padding: 8px; border-bottom: 1px solid #ddd;">${tanggalLahir}</td>
          </tr>
          <tr>
            <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Usia</td>
            <td style="padding: 8px; border-bottom: 1px solid #ddd;">${
              childData.usia
            } bulan</td>
          </tr>
          <tr>
            <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Jenis Kelamin</td>
            <td style="padding: 8px; border-bottom: 1px solid #ddd;">${
              childData.jenisKelamin === "laki-laki" ? "Laki-laki" : "Perempuan"
            }</td>
          </tr>
          <tr>
            <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Berat Badan</td>
            <td style="padding: 8px; border-bottom: 1px solid #ddd;">${
              childData.beratBadan
            } kg</td>
          </tr>
          <tr>
            <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Tinggi Badan</td>
            <td style="padding: 8px; border-bottom: 1px solid #ddd;">${
              childData.tinggiBadan
            } cm</td>
          </tr>
          <tr>
            <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Alamat</td>
            <td style="padding: 8px; border-bottom: 1px solid #ddd;">
              ${childData.alamat.desa}, ${childData.alamat.kecamatan}, ${
    childData.alamat.kabupaten
  }, ${childData.alamat.provinsi}
            </td>
          </tr>
        </table>
      </div>
      
      <div class="section" style="margin-bottom: 20px;">
        <div class="section-title" style="font-size: 18px; font-weight: bold; margin-bottom: 10px; color: #3b82f6;">Hasil Analisis</div>
        <div class="result" style="background-color: #f8fafc; padding: 15px; border-radius: 5px; border-left: 5px solid ${statusColor};">
          <div class="status" style="font-size: 18px; font-weight: bold; color: ${statusColor}; margin-bottom: 10px;">Status: ${statusText}</div>
          <div class="message" style="margin-bottom: 15px;">${
            result.message
          }</div>
          
          <div>Tingkat Risiko: ${result.score}%</div>
          <div class="progress-container" style="height: 20px; background-color: #e5e7eb; border-radius: 10px; margin: 15px 0;">
            <div class="progress-bar" style="height: 100%; border-radius: 10px; background-color: ${statusColor}; width: ${
    result.score
  }%;"></div>
          </div>
          
          <div class="recommendations" style="margin-top: 20px;">
            <div style="font-weight: bold; margin-bottom: 10px;">Rekomendasi:</div>
            ${result.recommendations
              .map(
                (rec) =>
                  `<div style="margin-bottom: 8px; padding-left: 20px; position: relative;">• ${rec}</div>`
              )
              .join("")}
          </div>
        </div>
      </div>
      
      <div class="section" style="margin-bottom: 20px;">
        <div class="section-title" style="font-size: 18px; font-weight: bold; margin-bottom: 10px; color: #3b82f6;">Artikel Rekomendasi</div>
        <ul>
          ${result.recommendedArticles
            .map((article) => `<li>${article.title} (${article.category})</li>`)
            .join("")}
        </ul>
      </div>
      
      <div class="footer" style="margin-top: 40px; text-align: center; font-size: 12px; color: #666; border-top: 1px solid #ddd; padding-top: 10px;">
        <p>Laporan ini dibuat secara otomatis oleh sistem ByeStunting.</p>
        <p>Silakan konsultasikan dengan tenaga kesehatan untuk penanganan lebih lanjut.</p>
        <p>© ${new Date().getFullYear()} ByeStunting - Cegah Stunting Indonesia</p>
      </div>
    </div>
  `;
}

// Fungsi untuk generate dan mendapatkan Blob PDF menggunakan html2pdf.js
export async function generatePdf(
  childData: ChildData,
  result: PredictionResult
): Promise<Blob> {
  return new Promise((resolve, reject) => {
    // Buat elemen sementara untuk menampung HTML
    const tempDiv = document.createElement("div");
    tempDiv.style.position = "fixed";
    tempDiv.style.left = "-9999px"; // agar tidak terlihat
    tempDiv.innerHTML = generatePdfContent(childData, result);
    document.body.appendChild(tempDiv);

    const opt = {
      margin: 0.5,
      filename: "laporan-stunting.pdf",
      image: { type: "jpeg", quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: "in", format: "a4", orientation: "portrait" },
    };

    html2pdf()
      .set(opt)
      .from(tempDiv)
      .outputPdf("blob")
      .then((pdfBlob: Blob) => {
        document.body.removeChild(tempDiv); // hapus elemen sementara
        resolve(pdfBlob);
      })
      .catch((err: any) => {
        document.body.removeChild(tempDiv);
        reject(err);
      });
  });
}

// Fungsi untuk mengunduh PDF dari Blob
export function downloadPdf(pdfBlob: Blob, filename: string) {
  const url = URL.createObjectURL(pdfBlob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}


// Fungsi untuk membagikan hasil via WhatsApp
export function shareViaWhatsApp(
  childData: ChildData,
  result: PredictionResult
): void {
  const statusText =
    result.status === "normal"
      ? "Normal"
      : result.status === "berisiko"
      ? "Berisiko Stunting"
      : "Stunting";

  const message = `
*Hasil Pemeriksaan Stunting*

Nama Anak: ${childData.nama}
Nama Ibu : ${childData.namaIbu}
Alamat: Ds.${childData.alamat.desa}, Kec.${childData.alamat.kecamatan}, ${childData.alamat.kabupaten}, Prov.${childData.alamat.provinsi}
Usia Anak: ${childData.usia} bulan
Tinggi Badan Anak : ${childData.tinggiBadan} cm
Berat Badan Anak : ${childData.beratBadan} kg
Status: *${statusText}*
Tingkat Risiko: ${result.score}%

${result.message}

*Rekomendasi:*
${result.recommendations.map((rec) => `- ${rec}`).join("\n")}

Periksa selengkapnya di aplikasi Website ByeStunting.
  `;

  const encodedMessage = encodeURIComponent(message);
  const whatsappUrl = `https://wa.me/?text=${encodedMessage}`;

  window.open(whatsappUrl, "_blank");
}
