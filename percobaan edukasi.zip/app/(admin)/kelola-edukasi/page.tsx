"use client";

import type React from "react";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Plus, Edit, Trash2, Eye, Heart, Calendar, X } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface Edukasi {
  id: number;
  title: string;
  summary: string;
  content: string;
  cover: string;
  category: string;
  youtubeUrl: string;
  articleUrl: string;
  tableOfContents: string[];
  createdDate: string;
  displayDate: string;
  likes: number;
  isPopular: boolean;
}

const categories = [
  "Pengetahuan Umum",
  "Nutrisi",
  "Tips Praktis",
  "Resep Makanan",
];

export default function EdukasiAdmin() {
  const [edukasiList, setEdukasiList] = useState<Edukasi[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingEdukasi, setEditingEdukasi] = useState<Edukasi | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    summary: "",
    content: "",
    cover: "",
    category: "",
    youtubeUrl: "",
    tableOfContents: [""],
  });

  useEffect(() => {
    fetchEdukasi();
  }, []);

  const fetchEdukasi = async () => {
    try {
      const response = await fetch("/api/articles");
      if (response.ok) {
        const data = await response.json();
        setEdukasiList(data);
      }
    } catch (error) {
      console.error("Error fetching edukasi:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (
      !formData.title ||
      !formData.summary ||
      !formData.content ||
      !formData.category
    ) {
      toast({
        title: "Error",
        description: "Mohon lengkapi semua field yang wajib diisi",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await fetch("/api/articles", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...formData,
          tableOfContents: formData.tableOfContents.filter(
            (item) => item.trim() !== ""
          ),
        }),
      });

      if (response.ok) {
        toast({
          title: "Berhasil",
          description: "Edukasi berhasil ditambahkan",
        });
        setIsDialogOpen(false);
        resetForm();
        fetchEdukasi();
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Terjadi kesalahan saat menyimpan edukasi",
        variant: "destructive",
      });
    }
  };

  const resetForm = () => {
    setFormData({
      title: "",
      summary: "",
      content: "",
      cover: "",
      category: "",
      youtubeUrl: "",
      tableOfContents: [""],
    });
    setEditingEdukasi(null);
  };

  const addTableOfContentsItem = () => {
    setFormData((prev) => ({
      ...prev,
      tableOfContents: [...prev.tableOfContents, ""],
    }));
  };

  const removeTableOfContentsItem = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      tableOfContents: prev.tableOfContents.filter((_, i) => i !== index),
    }));
  };

  const updateTableOfContentsItem = (index: number, value: string) => {
    setFormData((prev) => ({
      ...prev,
      tableOfContents: prev.tableOfContents.map((item, i) =>
        i === index ? value : item
      ),
    }));
  };

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">Kelola Edukasi</h1>
          <p className="text-gray-600 mt-2">
            Kelola konten edukasi stunting untuk pengguna
          </p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[#317BC4] hover:bg-[#2A6CB0]">
              <Plus className="h-4 w-4 mr-2" />
              Tambah Edukasi
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingEdukasi ? "Edit Edukasi" : "Tambah Edukasi Baru"}
              </DialogTitle>
            </DialogHeader>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Judul Edukasi *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        title: e.target.value,
                      }))
                    }
                    placeholder="Masukkan judul edukasi"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">Kategori *</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) =>
                      setFormData((prev) => ({ ...prev, category: value }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih kategori" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="summary">Ringkasan Edukasi *</Label>
                <Textarea
                  id="summary"
                  value={formData.summary}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      summary: e.target.value,
                    }))
                  }
                  placeholder="Masukkan ringkasan singkat edukasi"
                  rows={3}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="content">Konten Lengkap *</Label>
                <Textarea
                  id="content"
                  value={formData.content}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      content: e.target.value,
                    }))
                  }
                  placeholder="Masukkan konten lengkap edukasi"
                  rows={8}
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="cover">URL Cover Edukasi</Label>
                  <Input
                    id="cover"
                    value={formData.cover}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        cover: e.target.value,
                      }))
                    }
                    placeholder="https://example.com/image.jpg"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="youtubeUrl">Link YouTube (Opsional)</Label>
                  <Input
                    id="youtubeUrl"
                    value={formData.youtubeUrl}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        youtubeUrl: e.target.value,
                      }))
                    }
                    placeholder="https://www.youtube.com/watch?v=..."
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Daftar Isi</Label>
                <div className="space-y-2">
                  {formData.tableOfContents.map((item, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        value={item}
                        onChange={(e) =>
                          updateTableOfContentsItem(index, e.target.value)
                        }
                        placeholder={`Item daftar isi ${index + 1}`}
                      />
                      {formData.tableOfContents.length > 1 && (
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={() => removeTableOfContentsItem(index)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button
                    type="button"
                    variant="outline"
                    onClick={addTableOfContentsItem}
                    className="w-full"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Tambah Item Daftar Isi
                  </Button>
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsDialogOpen(false)}
                >
                  Batal
                </Button>
                <Button
                  type="submit"
                  className="bg-[#317BC4] hover:bg-[#2A6CB0]"
                >
                  {editingEdukasi ? "Update" : "Simpan"} Edukasi
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="list" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="list">Daftar Edukasi</TabsTrigger>
          <TabsTrigger value="popular">Edukasi Populer</TabsTrigger>
        </TabsList>

        <TabsContent value="list">
          <Card>
            <CardHeader>
              <CardTitle>Semua Edukasi ({edukasiList.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Judul</TableHead>
                    <TableHead>Kategori</TableHead>
                    <TableHead>Tanggal</TableHead>
                    <TableHead>Likes</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {edukasiList.map((edukasi) => (
                    <TableRow key={edukasi.id}>
                      <TableCell className="font-medium">
                        {edukasi.title}
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{edukasi.category}</Badge>
                      </TableCell>
                      <TableCell className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {edukasi.displayDate}
                      </TableCell>
                      <TableCell className="flex items-center gap-1">
                        <Heart className="h-4 w-4 text-red-500" />
                        {edukasi.likes}
                      </TableCell>
                      <TableCell>
                        {edukasi.isPopular && (
                          <Badge className="bg-yellow-500 hover:bg-yellow-600">
                            Populer
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="popular">
          <Card>
            <CardHeader>
              <CardTitle>Edukasi Populer</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {edukasiList
                  .filter((edukasi) => edukasi.isPopular)
                  .map((edukasi) => (
                    <Card key={edukasi.id} className="overflow-hidden">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <Badge className="bg-yellow-500 hover:bg-yellow-600">
                            Populer
                          </Badge>
                          <div className="flex items-center gap-1 text-sm text-gray-500">
                            <Heart className="h-4 w-4 text-red-500" />
                            {edukasi.likes}
                          </div>
                        </div>
                        <h3 className="font-semibold mb-2 line-clamp-2">
                          {edukasi.title}
                        </h3>
                        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                          {edukasi.summary}
                        </p>
                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <span>{edukasi.category}</span>
                          <span>{edukasi.displayDate}</span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
