import { NextResponse } from "next/server";

// Data edukasi dengan struktur baru
const edukasi = [
  {
    id: 1,
    title: "Mengenal Stunting dan Dampaknya pada Anak",
    summary:
      "Stunting adalah kondisi gagal tumbuh pada anak akibat kekurangan gizi kronis. Ketahui dampak jangka panjangnya pada perkembangan anak.",
    content:
      "Stunting adalah kondisi gagal tumbuh pada anak akibat kekurangan gizi kronis terutama dalam 1.000 hari pertama kehidupan. Kondisi ini ditandai dengan tinggi badan anak yang lebih pendek dibandingkan anak seusianya. Stunting tidak hanya berdampak pada fisik anak, tetapi juga pada perkembangan otak, yang dapat memengaruhi kemampuan kognitif dan prestasi belajar di masa depan. Selain itu, anak yang mengalami stunting juga berisiko lebih tinggi terkena penyakit tidak menular seperti diabetes dan penyakit jantung di masa dewasa.",
    cover: "/placeholder.svg?height=400&width=600",
    category: "Pengetahuan Umum",
    youtubeUrl: "https://www.youtube.com/watch?v=example1",
    articleUrl: "/edukasi/1",
    tableOfContents: [
      "Pengertian Stunting",
      "Penyebab Stunting",
      "Dampak Jangka Panjang",
      "Cara Pencegahan",
    ],
    createdDate: "2025-01-15",
    displayDate: "15 Januari 2025",
    likes: 45,
    isPopular: true,
  },
  {
    id: 2,
    title: "Nutrisi Penting untuk Mencegah Stunting",
    summary:
      "Pelajari nutrisi-nutrisi penting yang harus diberikan pada anak untuk mencegah stunting dan mendukung pertumbuhan optimal.",
    content:
      "Untuk mencegah stunting, anak membutuhkan asupan nutrisi yang lengkap dan seimbang. Beberapa nutrisi penting yang harus diperhatikan antara lain protein, kalsium, zat besi, zinc, vitamin A, vitamin D, dan asam folat. Protein berperan penting dalam pembentukan sel-sel tubuh dan pertumbuhan. Kalsium dan vitamin D diperlukan untuk pertumbuhan tulang dan gigi yang kuat.",
    cover: "/placeholder.svg?height=400&width=600",
    category: "Nutrisi",
    youtubeUrl: "",
    articleUrl: "/edukasi/2",
    tableOfContents: [
      "Protein untuk Pertumbuhan",
      "Vitamin dan Mineral Penting",
      "Sumber Makanan Bergizi",
      "Panduan Porsi Harian",
    ],
    createdDate: "2025-01-10",
    displayDate: "10 Januari 2025",
    likes: 32,
    isPopular: true,
  },
  {
    id: 3,
    title: "Pola Makan Seimbang untuk Anak Usia 1-3 Tahun",
    summary:
      "Panduan lengkap menyusun menu seimbang untuk anak usia 1-3 tahun yang mendukung pertumbuhan dan mencegah stunting.",
    content:
      "Pola makan seimbang untuk anak usia 1-3 tahun harus mencakup berbagai kelompok makanan, termasuk karbohidrat, protein, lemak, serta buah dan sayuran. Porsi makan untuk anak usia ini biasanya sekitar 3/4 hingga 1 cangkir makanan per waktu makan.",
    cover: "/placeholder.svg?height=400&width=600",
    category: "Tips Praktis",
    youtubeUrl: "https://www.youtube.com/watch?v=example3",
    articleUrl: "/edukasi/3",
    tableOfContents: [
      "Kebutuhan Kalori Harian",
      "Jadwal Makan yang Tepat",
      "Variasi Menu Sehat",
      "Tips Mengatasi Anak Susah Makan",
    ],
    createdDate: "2025-01-08",
    displayDate: "8 Januari 2025",
    likes: 28,
    isPopular: false,
  },
  {
    id: 4,
    title: "Resep Bubur Bergizi untuk Bayi 6-12 Bulan",
    summary:
      "Kumpulan resep bubur bergizi yang mudah dibuat dan aman untuk bayi usia 6-12 bulan sebagai MPASI pertama.",
    content:
      "MPASI (Makanan Pendamping ASI) sangat penting untuk mendukung pertumbuhan bayi. Berikut adalah resep-resep bubur bergizi yang dapat Anda buat di rumah dengan bahan-bahan alami dan bergizi tinggi.",
    cover: "/placeholder.svg?height=400&width=600",
    category: "Resep Makanan",
    youtubeUrl: "https://www.youtube.com/watch?v=example4",
    articleUrl: "/edukasi/4",
    tableOfContents: [
      "Bubur Beras Merah",
      "Bubur Ayam Sayuran",
      "Bubur Ikan Salmon",
      "Tips Penyimpanan MPASI",
    ],
    createdDate: "2025-01-05",
    displayDate: "5 Januari 2025",
    likes: 67,
    isPopular: true,
  },
  {
    id: 5,
    title: "Pentingnya 1000 Hari Pertama Kehidupan",
    summary:
      "1000 hari pertama kehidupan adalah periode kritis untuk pertumbuhan dan perkembangan anak. Ketahui mengapa periode ini sangat penting.",
    content:
      "1000 hari pertama kehidupan, mulai dari masa kehamilan hingga anak berusia 2 tahun, merupakan periode emas yang menentukan kualitas kesehatan, pertumbuhan, dan perkembangan anak di masa depan.",
    cover: "/placeholder.svg?height=400&width=600",
    category: "Pengetahuan Umum",
    youtubeUrl: "",
    articleUrl: "/edukasi/5",
    tableOfContents: [
      "Periode Emas Pertumbuhan",
      "Nutrisi Ibu Hamil",
      "ASI Eksklusif",
      "MPASI yang Tepat",
    ],
    createdDate: "2025-01-03",
    displayDate: "3 Januari 2025",
    likes: 41,
    isPopular: true,
  },
];

// GET /api/articles - Mendapatkan semua edukasi
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const category = searchParams.get("category");
  const search = searchParams.get("search");
  const popular = searchParams.get("popular");

  let filteredEdukasi = [...edukasi];

  // Filter berdasarkan kategori jika ada
  if (category && category !== "all") {
    filteredEdukasi = filteredEdukasi.filter(
      (item) => item.category === category
    );
  }

  // Filter berdasarkan pencarian jika ada
  if (search) {
    const searchLower = search.toLowerCase();
    filteredEdukasi = filteredEdukasi.filter(
      (item) =>
        item.title.toLowerCase().includes(searchLower) ||
        item.summary.toLowerCase().includes(searchLower)
    );
  }

  // Filter edukasi populer jika diminta
  if (popular === "true") {
    filteredEdukasi = filteredEdukasi.filter((item) => item.isPopular);
  }

  return NextResponse.json(filteredEdukasi);
}

// POST /api/articles - Menambahkan edukasi baru
export async function POST(request: Request) {
  try {
    const body = await request.json();

    // Validasi data
    if (!body.title || !body.summary || !body.content || !body.category) {
      return NextResponse.json(
        { error: "Data tidak lengkap" },
        { status: 400 }
      );
    }

    // Buat edukasi baru
    const newEdukasi = {
      id:
        edukasi.length > 0
          ? Math.max(...edukasi.map((item) => item.id)) + 1
          : 1,
      title: body.title,
      summary: body.summary,
      content: body.content,
      cover: body.cover || "/placeholder.svg?height=400&width=600",
      category: body.category,
      youtubeUrl: body.youtubeUrl || "",
      articleUrl: `/edukasi/${edukasi.length + 1}`,
      tableOfContents: body.tableOfContents || [],
      createdDate: new Date().toISOString().split("T")[0],
      displayDate: new Date().toLocaleDateString("id-ID", {
        day: "numeric",
        month: "long",
        year: "numeric",
      }),
      likes: 0,
      isPopular: false,
    };

    // Tambahkan ke array
    edukasi.unshift(newEdukasi);

    return NextResponse.json(newEdukasi, { status: 201 });
  } catch (error) {
    return NextResponse.json(
      { error: "Terjadi kesalahan saat memproses permintaan" },
      { status: 500 }
    );
  }
}
