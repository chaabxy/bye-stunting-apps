import { NextResponse } from "next/server"

// Data edukasi (sama seperti di route.ts)
const edukasi = [
  {
    id: 1,
    title: "Pentingnya Sarapan",
    content: "Sarapan memberikan energi untuk memulai hari.",
    likes: 25,
    isPopular: false,
  },
  {
    id: 2,
    title: "Manfaat Olahraga",
    content: "Olahraga meningkatkan kesehatan fisik dan mental.",
    likes: 40,
    isPopular: true,
  },
  {
    id: 3,
    title: "Tips Belajar Efektif",
    content: "Belajar dengan fokus dan teratur akan lebih efektif.",
    likes: 15,
    isPopular: false,
  },
]

// GET /api/articles/[id] - Mendapatkan edukasi berdasarkan ID
export async function GET(request: Request, { params }: { params: { id: string } }) {
  const id = Number.parseInt(params.id)
  const item = edukasi.find((e) => e.id === id)

  if (!item) {
    return NextResponse.json({ error: "Edukasi tidak ditemukan" }, { status: 404 })
  }

  return NextResponse.json(item)
}

// PATCH /api/articles/[id] - Update likes
export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    const id = Number.parseInt(params.id)
    const body = await request.json()

    const itemIndex = edukasi.findIndex((e) => e.id === id)

    if (itemIndex === -1) {
      return NextResponse.json({ error: "Edukasi tidak ditemukan" }, { status: 404 })
    }

    // Update likes
    if (body.action === "like") {
      edukasi[itemIndex].likes += 1
    } else if (body.action === "unlike") {
      edukasi[itemIndex].likes = Math.max(0, edukasi[itemIndex].likes - 1)
    }

    // Update status populer berdasarkan jumlah likes
    edukasi[itemIndex].isPopular = edukasi[itemIndex].likes >= 30

    return NextResponse.json(edukasi[itemIndex])
  } catch (error) {
    return NextResponse.json({ error: "Terjadi kesalahan saat memproses permintaan" }, { status: 500 })
  }
}
