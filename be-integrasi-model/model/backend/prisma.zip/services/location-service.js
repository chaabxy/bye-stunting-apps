const axios = require("axios");
const prisma = require("../lib/prisma");

/**
 * Service untuk mengelola data wilayah Indonesia
 * Menggunakan API dari https://www.emsifa.com/api-wilayah-indonesia/
 */

const BASE_URL = "https://www.emsifa.com/api-wilayah-indonesia/api";

class LocationService {
  /**
   * Mengambil semua data provinsi dari API dan menyimpan ke database
   */
  async syncProvinces() {
    try {
      console.log("🔄 Mengambil data provinsi dari API...");

      const response = await axios.get(`${BASE_URL}/provinces.json`);
      const provinces = response.data;

      console.log(`📍 Ditemukan ${provinces.length} provinsi`);

      // Simpan ke database menggunakan upsert
      const savedProvinces = [];
      for (const province of provinces) {
        const saved = await prisma.province.upsert({
          where: { id: province.id },
          update: { name: province.name },
          create: {
            id: province.id,
            name: province.name,
          },
        });
        savedProvinces.push(saved);
      }

      console.log(`✅ Berhasil menyimpan ${savedProvinces.length} provinsi`);
      return savedProvinces;
    } catch (error) {
      console.error("❌ Error syncing provinces:", error);
      throw new Error("Gagal mengambil data provinsi");
    }
  }

  /**
   * Mengambil data kabupaten/kota berdasarkan provinsi dan menyimpan ke database
   */
  async syncRegencies(provinceId) {
    try {
      console.log(
        `🔄 Mengambil data kabupaten/kota untuk provinsi ${provinceId}...`
      );

      const response = await axios.get(
        `${BASE_URL}/regencies/${provinceId}.json`
      );
      const regencies = response.data;

      console.log(`🏘️ Ditemukan ${regencies.length} kabupaten/kota`);

      // Simpan ke database
      const savedRegencies = [];
      for (const regency of regencies) {
        const saved = await prisma.regency.upsert({
          where: { id: regency.id },
          update: { name: regency.name },
          create: {
            id: regency.id,
            provinceId: regency.province_id,
            name: regency.name,
          },
        });
        savedRegencies.push(saved);
      }

      console.log(
        `✅ Berhasil menyimpan ${savedRegencies.length} kabupaten/kota`
      );
      return savedRegencies;
    } catch (error) {
      console.error("❌ Error syncing regencies:", error);
      throw new Error("Gagal mengambil data kabupaten/kota");
    }
  }

  /**
   * Mengambil data kecamatan berdasarkan kabupaten/kota dan menyimpan ke database
   */
  async syncDistricts(regencyId) {
    try {
      console.log(
        `🔄 Mengambil data kecamatan untuk kabupaten/kota ${regencyId}...`
      );

      const response = await axios.get(
        `${BASE_URL}/districts/${regencyId}.json`
      );
      const districts = response.data;

      console.log(`🏘️ Ditemukan ${districts.length} kecamatan`);

      // Simpan ke database
      const savedDistricts = [];
      for (const district of districts) {
        const saved = await prisma.district.upsert({
          where: { id: district.id },
          update: { name: district.name },
          create: {
            id: district.id,
            regencyId: district.regency_id,
            name: district.name,
          },
        });
        savedDistricts.push(saved);
      }

      console.log(`✅ Berhasil menyimpan ${savedDistricts.length} kecamatan`);
      return savedDistricts;
    } catch (error) {
      console.error("❌ Error syncing districts:", error);
      throw new Error("Gagal mengambil data kecamatan");
    }
  }

  /**
   * Mengambil data desa/kelurahan berdasarkan kecamatan dan menyimpan ke database
   */
  async syncVillages(districtId) {
    try {
      console.log(
        `🔄 Mengambil data desa/kelurahan untuk kecamatan ${districtId}...`
      );

      const response = await axios.get(
        `${BASE_URL}/villages/${districtId}.json`
      );
      const villages = response.data;

      console.log(`🏘️ Ditemukan ${villages.length} desa/kelurahan`);

      // Simpan ke database
      const savedVillages = [];
      for (const village of villages) {
        const saved = await prisma.village.upsert({
          where: { id: village.id },
          update: { name: village.name },
          create: {
            id: village.id,
            districtId: village.district_id,
            name: village.name,
          },
        });
        savedVillages.push(saved);
      }

      console.log(
        `✅ Berhasil menyimpan ${savedVillages.length} desa/kelurahan`
      );
      return savedVillages;
    } catch (error) {
      console.error("❌ Error syncing villages:", error);
      throw new Error("Gagal mengambil data desa/kelurahan");
    }
  }

  /**
   * Sync semua data wilayah Indonesia (HATI-HATI: Proses ini lama!)
   */
  async syncAllLocationData() {
    try {
      console.log("🚀 Memulai sinkronisasi semua data wilayah Indonesia...");

      // 1. Sync provinsi
      const provinces = await this.syncProvinces();

      // 2. Sync kabupaten/kota untuk setiap provinsi
      for (const province of provinces) {
        await this.syncRegencies(province.id);

        // Delay untuk menghindari rate limiting
        await new Promise((resolve) => setTimeout(resolve, 100));
      }

      console.log("✅ Sinkronisasi semua data wilayah selesai!");
      return {
        success: true,
        message: "Semua data wilayah berhasil disinkronisasi",
      };
    } catch (error) {
      console.error("❌ Error syncing all location data:", error);
      throw error;
    }
  }

  /**
   * Generate data statistik stunting dummy untuk setiap provinsi
   */
  async generateDummyStuntingStats() {
    try {
      console.log("🔄 Generating dummy stunting statistics...");

      const provinces = await prisma.province.findMany();

      const statsData = [];
      for (const province of provinces) {
        // Generate data dummy yang realistis
        const stunting = Math.floor(Math.random() * 15) + 10; // 10-25%
        const risk = Math.floor(Math.random() * 20) + 15; // 15-35%
        const normal = 100 - stunting - risk;
        const totalChildren = Math.floor(Math.random() * 50000) + 10000; // 10k-60k anak

        const stats = await prisma.provinceStuntingStats.upsert({
          where: {
            provinceId_year: {
              provinceId: province.id,
              year: 2024,
            },
          },
          update: {
            normal,
            risk,
            stunting,
            totalChildren,
          },
          create: {
            provinceId: province.id,
            normal,
            risk,
            stunting,
            totalChildren,
            year: 2024,
          },
        });

        statsData.push(stats);
      }

      console.log(`✅ Generated dummy stats for ${statsData.length} provinces`);
      return statsData;
    } catch (error) {
      console.error("❌ Error generating dummy stats:", error);
      throw error;
    }
  }

  /**
   * Ambil data provinsi dari database
   */
  async getProvinces() {
    try {
      const provinces = await prisma.province.findMany({
        orderBy: { name: "asc" },
      });
      return provinces;
    } catch (error) {
      console.error("❌ Error getting provinces:", error);
      throw new Error("Gagal mengambil data provinsi");
    }
  }

  /**
   * Ambil statistik stunting berdasarkan provinsi
   */
  async getProvinceStuntingStats(provinceId) {
    try {
      const stats = await prisma.provinceStuntingStats.findFirst({
        where: {
          provinceId,
          year: 2024,
        },
      });

      if (!stats) {
        // Return default data jika tidak ada
        return {
          normal: 0,
          risk: 0,
          stunting: 0,
          totalChildren: 0,
        };
      }

      return {
        normal: stats.normal,
        risk: stats.risk,
        stunting: stats.stunting,
        totalChildren: stats.totalChildren,
      };
    } catch (error) {
      console.error("❌ Error getting province stunting stats:", error);
      throw new Error("Gagal mengambil statistik stunting provinsi");
    }
  }
}

module.exports = new LocationService();
