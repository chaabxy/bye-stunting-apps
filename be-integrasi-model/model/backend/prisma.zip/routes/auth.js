.const Joi = require("joi")
const { hashPassword, comparePassword, generateToken } = require("../lib/auth")
const prisma = require("../lib/prisma")

const authRoutes = [
  // Login
  {
    method: "POST",
    path: "/api/auth/login",
    options: {
      validate: {
        payload: Joi.object({
          email: Joi.string().email().required(),
          password: Joi.string().min(6).required(),
        }),
      },
    },
    handler: async (request, h) => {
      try {
        const { email, password } = request.payload

        // Find user
        const user = await prisma.user.findUnique({
          where: { email },
        })

        if (!user) {
          return h
            .response({
              isError: true,
              message: "Email atau password salah",
            })
            .code(401)
        }

        // Check password
        const isValidPassword = await comparePassword(password, user.password)
        if (!isValidPassword) {
          return h
            .response({
              isError: true,
              message: "Email atau password salah",
            })
            .code(401)
        }

        // Generate token
        const token = generateToken(user)

        return h
          .response({
            isError: false,
            message: "Login berhasil",
            data: {
              token,
              user: {
                id: user.id,
                email: user.email,
                name: user.name,
                role: user.role,
              },
            },
          })
          .code(200)
      } catch (error) {
        console.error("Login error:", error)
        return h
          .response({
            isError: true,
            message: "Terjadi kesalahan saat login",
          })
          .code(500)
      }
    },
  },

  // Register
  {
    method: "POST",
    path: "/api/auth/register",
    options: {
      validate: {
        payload: Joi.object({
          name: Joi.string().min(2).required(),
          email: Joi.string().email().required(),
          password: Joi.string().min(6).required(),
        }),
      },
    },
    handler: async (request, h) => {
      try {
        const { name, email, password } = request.payload

        // Check if user exists
        const existingUser = await prisma.user.findUnique({
          where: { email },
        })

        if (existingUser) {
          return h
            .response({
              isError: true,
              message: "Email sudah terdaftar",
            })
            .code(400)
        }

        // Hash password
        const hashedPassword = await hashPassword(password)

        // Create user
        const user = await prisma.user.create({
          data: {
            name,
            email,
            password: hashedPassword,
          },
        })

        // Generate token
        const token = generateToken(user)

        return h
          .response({
            isError: false,
            message: "Registrasi berhasil",
            data: {
              token,
              user: {
                id: user.id,
                email: user.email,
                name: user.name,
                role: user.role,
              },
            },
          })
          .code(201)
      } catch (error) {
        console.error("Register error:", error)
        return h
          .response({
            isError: true,
            message: "Terjadi kesalahan saat registrasi",
          })
          .code(500)
      }
    },
  },
]

module.exports = authRoutes
