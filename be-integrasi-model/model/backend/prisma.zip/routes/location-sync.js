const axios = require("axios")
const { PrismaClient } = require("@prisma/client")

const prisma = new PrismaClient()

/**
 * Routes untuk sync data wilayah dari API eksternal ke database
 * Mengambil data dari API -> Langsung simpan ke database
 */

const BASE_URL = "https://www.emsifa.com/api-wilayah-indonesia/api"

const locationSyncRoutes = [
  // Sync provinces: GET dari API -> POST ke database
  {
    method: "POST",
    path: "/api/sync/provinces",
    handler: async (request, h) => {
      try {
        console.log("🔄 Fetching provinces from external API...")

        // 1. GET data dari API eksternal
        const response = await axios.get(`${BASE_URL}/provinces.json`)
        const provincesFromAPI = response.data

        console.log(`📍 Fetched ${provincesFromAPI.length} provinces from API`)

        // 2. POST/Save ke database
        const savedProvinces = []
        for (const province of provincesFromAPI) {
          const saved = await prisma.province.upsert({
            where: { id: province.id },
            update: {
              name: province.name,
              updatedAt: new Date(),
            },
            create: {
              id: province.id,
              name: province.name,
            },
          })
          savedProvinces.push(saved)
        }

        console.log(`✅ Successfully saved ${savedProvinces.length} provinces to database`)

        return h
          .response({
            isError: false,
            message: `Berhasil sync ${savedProvinces.length} provinsi dari API ke database`,
            data: {
              totalFetched: provincesFromAPI.length,
              totalSaved: savedProvinces.length,
              provinces: savedProvinces,
            },
          })
          .code(200)
      } catch (error) {
        console.error("❌ Error syncing provinces:", error)
        return h
          .response({
            isError: true,
            message: error.message || "Gagal sync data provinsi dari API",
            error: error.response?.data || error.message,
          })
          .code(500)
      }
    },
  },

  // Sync regencies by province: GET dari API -> POST ke database
  {
    method: "POST",
    path: "/api/sync/regencies/{provinceId}",
    handler: async (request, h) => {
      try {
        const { provinceId } = request.params

        console.log(`🔄 Fetching regencies for province ${provinceId} from external API...`)

        // 1. GET data dari API eksternal
        const response = await axios.get(`${BASE_URL}/regencies/${provinceId}.json`)
        const regenciesFromAPI = response.data

        console.log(`🏘️ Fetched ${regenciesFromAPI.length} regencies from API`)

        // 2. POST/Save ke database
        const savedRegencies = []
        for (const regency of regenciesFromAPI) {
          const saved = await prisma.regency.upsert({
            where: { id: regency.id },
            update: {
              name: regency.name,
              updatedAt: new Date(),
            },
            create: {
              id: regency.id,
              provinceId: regency.province_id,
              name: regency.name,
            },
          })
          savedRegencies.push(saved)
        }

        console.log(`✅ Successfully saved ${savedRegencies.length} regencies to database`)

        return h
          .response({
            isError: false,
            message: `Berhasil sync ${savedRegencies.length} kabupaten/kota dari API ke database`,
            data: {
              provinceId,
              totalFetched: regenciesFromAPI.length,
              totalSaved: savedRegencies.length,
              regencies: savedRegencies,
            },
          })
          .code(200)
      } catch (error) {
        const { provinceId } = request.params
        console.error(`❌ Error syncing regencies for province ${provinceId}:`, error)
        return h
          .response({
            isError: true,
            message: error.message || "Gagal sync data kabupaten/kota dari API",
            error: error.response?.data || error.message,
          })
          .code(500)
      }
    },
  },

  // Sync districts by regency: GET dari API -> POST ke database
  {
    method: "POST",
    path: "/api/sync/districts/{regencyId}",
    handler: async (request, h) => {
      try {
        const { regencyId } = request.params

        console.log(`🔄 Fetching districts for regency ${regencyId} from external API...`)

        // 1. GET data dari API eksternal
        const response = await axios.get(`${BASE_URL}/districts/${regencyId}.json`)
        const districtsFromAPI = response.data

        console.log(`🏘️ Fetched ${districtsFromAPI.length} districts from API`)

        // 2. POST/Save ke database
        const savedDistricts = []
        for (const district of districtsFromAPI) {
          const saved = await prisma.district.upsert({
            where: { id: district.id },
            update: {
              name: district.name,
              updatedAt: new Date(),
            },
            create: {
              id: district.id,
              regencyId: district.regency_id,
              name: district.name,
            },
          })
          savedDistricts.push(saved)
        }

        console.log(`✅ Successfully saved ${savedDistricts.length} districts to database`)

        return h
          .response({
            isError: false,
            message: `Berhasil sync ${savedDistricts.length} kecamatan dari API ke database`,
            data: {
              regencyId,
              totalFetched: districtsFromAPI.length,
              totalSaved: savedDistricts.length,
              districts: savedDistricts,
            },
          })
          .code(200)
      } catch (error) {
        const { regencyId } = request.params
        console.error(`❌ Error syncing districts for regency ${regencyId}:`, error)
        return h
          .response({
            isError: true,
            message: error.message || "Gagal sync data kecamatan dari API",
            error: error.response?.data || error.message,
          })
          .code(500)
      }
    },
  },

  // Sync villages by district: GET dari API -> POST ke database
  {
    method: "POST",
    path: "/api/sync/villages/{districtId}",
    handler: async (request, h) => {
      try {
        const { districtId } = request.params

        console.log(`🔄 Fetching villages for district ${districtId} from external API...`)

        // 1. GET data dari API eksternal
        const response = await axios.get(`${BASE_URL}/villages/${districtId}.json`)
        const villagesFromAPI = response.data

        console.log(`🏘️ Fetched ${villagesFromAPI.length} villages from API`)

        // 2. POST/Save ke database
        const savedVillages = []
        for (const village of villagesFromAPI) {
          const saved = await prisma.village.upsert({
            where: { id: village.id },
            update: {
              name: village.name,
              updatedAt: new Date(),
            },
            create: {
              id: village.id,
              districtId: village.district_id,
              name: village.name,
            },
          })
          savedVillages.push(saved)
        }

        console.log(`✅ Successfully saved ${savedVillages.length} villages to database`)

        return h
          .response({
            isError: false,
            message: `Berhasil sync ${savedVillages.length} desa/kelurahan dari API ke database`,
            data: {
              districtId,
              totalFetched: villagesFromAPI.length,
              totalSaved: savedVillages.length,
              villages: savedVillages,
            },
          })
          .code(200)
      } catch (error) {
        const { districtId } = request.params
        console.error(`❌ Error syncing villages for district ${districtId}:`, error)
        return h
          .response({
            isError: true,
            message: error.message || "Gagal sync data desa/kelurahan dari API",
            error: error.response?.data || error.message,
          })
          .code(500)
      }
    },
  },

  // Sync ALL provinces and their regencies: GET dari API -> POST ke database
  {
    method: "POST",
    path: "/api/sync/all-locations",
    handler: async (request, h) => {
      try {
        console.log("🚀 Starting full location sync from API to database...")

        let totalProvinces = 0
        let totalRegencies = 0
        const results = []

        // 1. Sync provinces first
        console.log("📍 Step 1: Syncing provinces...")
        const provincesResponse = await axios.get(`${BASE_URL}/provinces.json`)
        const provincesFromAPI = provincesResponse.data

        const savedProvinces = []
        for (const province of provincesFromAPI) {
          const saved = await prisma.province.upsert({
            where: { id: province.id },
            update: {
              name: province.name,
              updatedAt: new Date(),
            },
            create: {
              id: province.id,
              name: province.name,
            },
          })
          savedProvinces.push(saved)
        }
        totalProvinces = savedProvinces.length

        // 2. Sync regencies for each province
        console.log("🏘️ Step 2: Syncing regencies for each province...")
        for (let i = 0; i < savedProvinces.length; i++) {
          const province = savedProvinces[i]

          try {
            console.log(`[${i + 1}/${savedProvinces.length}] Syncing regencies for ${province.name}...`)

            const regenciesResponse = await axios.get(`${BASE_URL}/regencies/${province.id}.json`)
            const regenciesFromAPI = regenciesResponse.data

            const savedRegencies = []
            for (const regency of regenciesFromAPI) {
              const saved = await prisma.regency.upsert({
                where: { id: regency.id },
                update: {
                  name: regency.name,
                  updatedAt: new Date(),
                },
                create: {
                  id: regency.id,
                  provinceId: regency.province_id,
                  name: regency.name,
                },
              })
              savedRegencies.push(saved)
            }

            totalRegencies += savedRegencies.length
            results.push({
              province: province.name,
              regenciesCount: savedRegencies.length,
            })

            // Delay untuk menghindari rate limiting
            await new Promise((resolve) => setTimeout(resolve, 200))
          } catch (error) {
            console.error(`❌ Error syncing regencies for ${province.name}:`, error.message)
            results.push({
              province: province.name,
              regenciesCount: 0,
              error: error.message,
            })
          }
        }

        console.log("🎉 Full location sync completed!")

        return h
          .response({
            isError: false,
            message: `Berhasil sync semua data wilayah dari API ke database`,
            data: {
              summary: {
                totalProvinces,
                totalRegencies,
                processedAt: new Date().toISOString(),
              },
              details: results,
            },
          })
          .code(200)
      } catch (error) {
        console.error("❌ Error in full location sync:", error)
        return h
          .response({
            isError: true,
            message: error.message || "Gagal sync semua data wilayah dari API",
            error: error.response?.data || error.message,
          })
          .code(500)
      }
    },
  },

  // Generate dummy stunting statistics
  {
    method: "POST",
    path: "/api/sync/stunting-stats",
    handler: async (request, h) => {
      try {
        console.log("📊 Generating stunting statistics for all provinces...")

        // Get all provinces from database
        const provinces = await prisma.province.findMany()

        if (provinces.length === 0) {
          return h
            .response({
              isError: true,
              message: "Tidak ada data provinsi. Sync provinsi terlebih dahulu.",
            })
            .code(400)
        }

        const statsData = []
        for (const province of provinces) {
          // Generate realistic dummy data
          const stunting = Math.floor(Math.random() * 15) + 10 // 10-25%
          const risk = Math.floor(Math.random() * 20) + 15 // 15-35%
          const normal = 100 - stunting - risk
          const totalChildren = Math.floor(Math.random() * 50000) + 10000 // 10k-60k children

          const stats = await prisma.provinceStuntingStats.upsert({
            where: {
              provinceId_year: {
                provinceId: province.id,
                year: 2024,
              },
            },
            update: {
              normal,
              risk,
              stunting,
              totalChildren,
              updatedAt: new Date(),
            },
            create: {
              provinceId: province.id,
              normal,
              risk,
              stunting,
              totalChildren,
              year: 2024,
            },
          })

          statsData.push({
            province: province.name,
            normal,
            risk,
            stunting,
            totalChildren,
          })

          console.log(
            `📊 Generated stats for ${province.name}: Normal ${normal}%, Risk ${risk}%, Stunting ${stunting}%`,
          )
        }

        return h
          .response({
            isError: false,
            message: `Berhasil generate statistik stunting untuk ${statsData.length} provinsi`,
            data: {
              totalProvinces: statsData.length,
              generatedAt: new Date().toISOString(),
              statistics: statsData,
            },
          })
          .code(200)
      } catch (error) {
        console.error("❌ Error generating stunting stats:", error)
        return h
          .response({
            isError: true,
            message: error.message || "Gagal generate statistik stunting",
            error: error.message,
          })
          .code(500)
      }
    },
  },
]

module.exports = locationSyncRoutes
