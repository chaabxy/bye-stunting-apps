const Joi = require("joi")
const { authMiddleware, adminMiddleware } = require("../lib/auth")
const prisma = require("../lib/prisma")

const adminRoutes = [
  // Get all predictions (Admin only)
  {
    method: "GET",
    path: "/api/admin/predictions",
    options: {
      pre: [authMiddleware, adminMiddleware],
    },
    handler: async (request, h) => {
      try {
        const { page = 1, limit = 10, search } = request.query

        const skip = (page - 1) * limit
        const where = search
          ? {
              OR: [
                { nama: { contains: search, mode: "insensitive" } },
                { status: { contains: search, mode: "insensitive" } },
              ],
            }
          : {}

        const [predictions, total] = await Promise.all([
          prisma.prediction.findMany({
            where,
            skip,
            take: Number.parseInt(limit),
            orderBy: { createdAt: "desc" },
            include: {
              user: {
                select: { name: true, email: true },
              },
            },
          }),
          prisma.prediction.count({ where }),
        ])

        return h
          .response({
            isError: false,
            data: {
              predictions,
              pagination: {
                page: Number.parseInt(page),
                limit: Number.parseInt(limit),
                total,
                totalPages: Math.ceil(total / limit),
              },
            },
          })
          .code(200)
      } catch (error) {
        console.error("Get predictions error:", error)
        return h
          .response({
            isError: true,
            message: "Gagal mengambil data prediksi",
          })
          .code(500)
      }
    },
  },

  // Get dashboard stats (Admin only)
  {
    method: "GET",
    path: "/api/admin/stats",
    options: {
      pre: [authMiddleware, adminMiddleware],
    },
    handler: async (request, h) => {
      try {
        const [totalPredictions, totalUsers, stuntingCount, normalCount, todayPredictions] = await Promise.all([
          prisma.prediction.count(),
          prisma.user.count({ where: { role: "USER" } }),
          prisma.prediction.count({ where: { status: "stunting" } }),
          prisma.prediction.count({ where: { status: "normal" } }),
          prisma.prediction.count({
            where: {
              createdAt: {
                gte: new Date(new Date().setHours(0, 0, 0, 0)),
              },
            },
          }),
        ])

        return h
          .response({
            isError: false,
            data: {
              totalPredictions,
              totalUsers,
              stuntingCount,
              normalCount,
              todayPredictions,
              stuntingPercentage: totalPredictions > 0 ? ((stuntingCount / totalPredictions) * 100).toFixed(1) : 0,
            },
          })
          .code(200)
      } catch (error) {
        console.error("Get stats error:", error)
        return h
          .response({
            isError: true,
            message: "Gagal mengambil statistik",
          })
          .code(500)
      }
    },
  },

  // Manage articles
  {
    method: "GET",
    path: "/api/admin/articles",
    options: {
      pre: [authMiddleware, adminMiddleware],
    },
    handler: async (request, h) => {
      try {
        const articles = await prisma.article.findMany({
          orderBy: { createdAt: "desc" },
        })

        return h
          .response({
            isError: false,
            data: articles,
          })
          .code(200)
      } catch (error) {
        console.error("Get articles error:", error)
        return h
          .response({
            isError: true,
            message: "Gagal mengambil artikel",
          })
          .code(500)
      }
    },
  },

  // Create article
  {
    method: "POST",
    path: "/api/admin/articles",
    options: {
      pre: [authMiddleware, adminMiddleware],
      validate: {
        payload: Joi.object({
          title: Joi.string().required(),
          content: Joi.string().required(),
          category: Joi.string().required(),
          imageUrl: Joi.string().optional(),
          isPublished: Joi.boolean().default(true),
        }),
      },
    },
    handler: async (request, h) => {
      try {
        const article = await prisma.article.create({
          data: request.payload,
        })

        return h
          .response({
            isError: false,
            message: "Artikel berhasil dibuat",
            data: article,
          })
          .code(201)
      } catch (error) {
        console.error("Create article error:", error)
        return h
          .response({
            isError: true,
            message: "Gagal membuat artikel",
          })
          .code(500)
      }
    },
  },
]

module.exports = adminRoutes
