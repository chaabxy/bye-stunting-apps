const { PrismaClient } = require("@prisma/client")

const prisma = new PrismaClient()

/**
 * Routes untuk mengambil data wilayah dari database (untuk frontend)
 */

const locationDataRoutes = [
  // Get provinces from database
  {
    method: "GET",
    path: "/api/provinces",
    handler: async (request, h) => {
      try {
        const provinces = await prisma.province.findMany({
          orderBy: { name: "asc" },
        })

        return h
          .response({
            isError: false,
            data: provinces,
          })
          .code(200)
      } catch (error) {
        console.error("Get provinces error:", error)
        return h
          .response({
            isError: true,
            message: "Gagal mengambil data provinsi",
          })
          .code(500)
      }
    },
  },

  // Get regencies by province from database
  {
    method: "GET",
    path: "/api/regencies/{provinceId}",
    handler: async (request, h) => {
      try {
        const { provinceId } = request.params

        const regencies = await prisma.regency.findMany({
          where: { provinceId },
          orderBy: { name: "asc" },
        })

        return h
          .response({
            isError: false,
            data: regencies,
          })
          .code(200)
      } catch (error) {
        console.error("Get regencies error:", error)
        return h
          .response({
            isError: true,
            message: "Gagal mengambil data kabupaten/kota",
          })
          .code(500)
      }
    },
  },

  // Get province stunting statistics (untuk komponen ProvinceStatsCard)
  {
    method: "GET",
    path: "/api/health-data/province-detail",
    handler: async (request, h) => {
      try {
        const { provinceId } = request.query

        if (!provinceId) {
          return h
            .response({
              isError: true,
              message: "Province ID is required",
            })
            .code(400)
        }

        const stats = await prisma.provinceStuntingStats.findFirst({
          where: {
            provinceId,
            year: 2024,
          },
        })

        if (!stats) {
          return h
            .response({
              normal: 0,
              risk: 0,
              stunting: 0,
              totalChildren: 0,
            })
            .code(200)
        }

        return h
          .response({
            normal: stats.normal,
            risk: stats.risk,
            stunting: stats.stunting,
            totalChildren: stats.totalChildren,
          })
          .code(200)
      } catch (error) {
        console.error("Get province stats error:", error)
        return h
          .response({
            isError: true,
            message: "Gagal mengambil statistik provinsi",
          })
          .code(500)
      }
    },
  },
]

module.exports = locationDataRoutes
