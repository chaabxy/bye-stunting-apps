const Joi = require("joi")
const locationService = require("../services/location-service")

const locationRoutes = [
  // Sync data provinsi dari API
  {
    method: "POST",
    path: "/api/admin/sync/provinces",
    options: {
      auth: "jwt",
      pre: [{ method: "requireAdmin" }],
    },
    handler: async (request, h) => {
      try {
        const result = await locationService.syncProvinces()

        return h
          .response({
            isError: false,
            message: `Berhasil menyinkronisasi ${result.length} provinsi`,
            data: result,
          })
          .code(200)
      } catch (error) {
        console.error("Sync provinces error:", error)
        return h
          .response({
            isError: true,
            message: error.message || "Gagal menyinkronisasi data provinsi",
          })
          .code(500)
      }
    },
  },

  // Sync data kabupaten/kota berdasarkan provinsi
  {
    method: "POST",
    path: "/api/admin/sync/regencies/{provinceId}",
    options: {
      auth: "jwt",
      pre: [{ method: "requireAdmin" }],
      validate: {
        params: Joi.object({
          provinceId: Joi.string().required(),
        }),
      },
    },
    handler: async (request, h) => {
      try {
        const { provinceId } = request.params
        const result = await locationService.syncRegencies(provinceId)

        return h
          .response({
            isError: false,
            message: `Berhasil menyinkronisasi ${result.length} kabupaten/kota`,
            data: result,
          })
          .code(200)
      } catch (error) {
        console.error("Sync regencies error:", error)
        return h
          .response({
            isError: true,
            message: error.message || "Gagal menyinkronisasi data kabupaten/kota",
          })
          .code(500)
      }
    },
  },

  // Sync semua data wilayah (HATI-HATI: Proses lama!)
  {
    method: "POST",
    path: "/api/admin/sync/all-locations",
    options: {
      auth: "jwt",
      pre: [{ method: "requireAdmin" }],
      timeout: {
        server: 30 * 60 * 1000, // 30 menit
      },
    },
    handler: async (request, h) => {
      try {
        const result = await locationService.syncAllLocationData()

        return h
          .response({
            isError: false,
            message: "Berhasil menyinkronisasi semua data wilayah",
            data: result,
          })
          .code(200)
      } catch (error) {
        console.error("Sync all locations error:", error)
        return h
          .response({
            isError: true,
            message: error.message || "Gagal menyinkronisasi semua data wilayah",
          })
          .code(500)
      }
    },
  },

  // Generate dummy stunting statistics
  {
    method: "POST",
    path: "/api/admin/generate/stunting-stats",
    options: {
      auth: "jwt",
      pre: [{ method: "requireAdmin" }],
    },
    handler: async (request, h) => {
      try {
        const result = await locationService.generateDummyStuntingStats()

        return h
          .response({
            isError: false,
            message: `Berhasil generate statistik stunting untuk ${result.length} provinsi`,
            data: result,
          })
          .code(200)
      } catch (error) {
        console.error("Generate stunting stats error:", error)
        return h
          .response({
            isError: true,
            message: error.message || "Gagal generate statistik stunting",
          })
          .code(500)
      }
    },
  },

  // Get provinces (public)
  {
    method: "GET",
    path: "/api/provinces",
    handler: async (request, h) => {
      try {
        const provinces = await locationService.getProvinces()

        return h
          .response({
            isError: false,
            data: provinces,
          })
          .code(200)
      } catch (error) {
        console.error("Get provinces error:", error)
        return h
          .response({
            isError: true,
            message: error.message || "Gagal mengambil data provinsi",
          })
          .code(500)
      }
    },
  },

  // Get province stunting statistics (untuk komponen Anda)
  {
    method: "GET",
    path: "/api/health-data/province-detail",
    options: {
      validate: {
        query: Joi.object({
          provinceId: Joi.string().required(),
        }),
      },
    },
    handler: async (request, h) => {
      try {
        const { provinceId } = request.query
        const stats = await locationService.getProvinceStuntingStats(provinceId)

        return h.response(stats).code(200)
      } catch (error) {
        console.error("Get province stats error:", error)
        return h
          .response({
            isError: true,
            message: error.message || "Gagal mengambil statistik provinsi",
          })
          .code(500)
      }
    },
  },
]

module.exports = locationRoutes
