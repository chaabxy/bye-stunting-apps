import EdukasiView from "@/view/edukasi-view.tsx";

export default function EdukasiPage() {
  return <EdukasiView />;
}
