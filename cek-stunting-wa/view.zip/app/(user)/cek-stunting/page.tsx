import CekStunting from "@/view/cek-stunting-view";

export default function CekStuntingPage() {
  return <CekStunting />;
}
