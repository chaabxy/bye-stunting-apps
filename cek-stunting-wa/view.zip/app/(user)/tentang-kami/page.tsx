import TentangKami from "@/view/tentang-kami-view";

export default function TentangKamiPage() {
  return <TentangKami />;
}
