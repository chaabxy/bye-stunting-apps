import Kontak from "@/view/kontak-view";

export default function KontakPage() {
  return <Kontak />;
}
