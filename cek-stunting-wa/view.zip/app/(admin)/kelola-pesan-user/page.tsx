import KelolaPesanUserView from "@/view/kelola-pesan-user.tsx";

export default function KelolaPesanUserPage() {
  return <KelolaPesanUserView />;
}
