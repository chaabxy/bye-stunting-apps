import KelolaDataStuntingView from "@/view/kelola-data-stunting-view";

export default function KelolaDataStuntingPage() {
  return <KelolaDataStuntingView />;
}
