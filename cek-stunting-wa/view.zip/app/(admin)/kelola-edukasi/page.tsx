import KelolaEdukasi from "@/view/kelola-edukasi-view.tsx"

export default function KelolaEdukasiPage() {
  return <KelolaEdukasi />
}
