import AdminLoginView from "@/view/admin-login-view";

export default function AdminLoginPage() {
  return <AdminLoginView />;
}
