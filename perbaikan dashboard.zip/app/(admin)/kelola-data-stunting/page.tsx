"use client";

import {
  Plus,
  Search,
  Edit,
  Download,
  BarChart3,
  Eye,
  Loader2,
  Users,
  Filter,
} from "lucide-react";
import { useState, useEffect } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ScatterChart,
  Scatter,
} from "recharts";
import { provinces } from "@/lib/location-data";

type StuntingData = {
  id: string;
  namaAnak: string;
  namaIbu: string;
  tanggalLahir: string;
  jenisKelamin: string;
  beratBadan: number;
  tinggiBadan: number;
  usia: number;
  provinsi: string;
  kabupaten: string;
  kecamatan: string;
  desa: string;
  status: "normal" | "berisiko" | "stunting";
  risiko: number;
  tanggalPemeriksaan: string;
};

export default function KelolaDataStunting() {
  const [data, setData] = useState<StuntingData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isChartDialogOpen, setIsChartDialogOpen] = useState(false);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);
  const [selectedData, setSelectedData] = useState<StuntingData | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedProvinsi, setSelectedProvinsi] = useState("all");
  const [selectedKabupaten, setSelectedKabupaten] = useState("all");
  const [selectedKecamatan, setSelectedKecamatan] = useState("all");
  const [selectedDesa, setSelectedDesa] = useState("all");
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Data untuk dropdown filter
  const [kabupatens, setKabupatens] = useState<string[]>([]);
  const [kecamatans, setKecamatans] = useState<string[]>([]);
  const [desas, setDesas] = useState<string[]>([]);

  useEffect(() => {
    // Simulate fetching data from localStorage or API
    setTimeout(() => {
      const mockData: StuntingData[] = [
        {
          id: "1",
          namaAnak: "Andi",
          namaIbu: "Siti",
          tanggalLahir: "2021-05-03",
          jenisKelamin: "laki-laki",
          beratBadan: 10.5,
          tinggiBadan: 85.5,
          usia: 43,
          provinsi: "Jawa Barat",
          kabupaten: "Garut",
          kecamatan: "Cilawu",
          desa: "Sukamurni",
          status: "normal",
          risiko: 15,
          tanggalPemeriksaan: "2024-01-20",
        },
        {
          id: "2",
          namaAnak: "Rina",
          namaIbu: "Dewi",
          tanggalLahir: "2020-10-10",
          jenisKelamin: "perempuan",
          beratBadan: 8.0,
          tinggiBadan: 78.0,
          usia: 51,
          provinsi: "Jawa Tengah",
          kabupaten: "Semarang",
          kecamatan: "Tembalang",
          desa: "Sendangmulyo",
          status: "berisiko",
          risiko: 45,
          tanggalPemeriksaan: "2024-01-18",
        },
        {
          id: "3",
          namaAnak: "Budi",
          namaIbu: "Ani",
          tanggalLahir: "2022-03-15",
          jenisKelamin: "laki-laki",
          beratBadan: 7.2,
          tinggiBadan: 70.0,
          usia: 22,
          provinsi: "Jawa Timur",
          kabupaten: "Malang",
          kecamatan: "Klojen",
          desa: "Kauman",
          status: "stunting",
          risiko: 75,
          tanggalPemeriksaan: "2024-01-15",
        },
        {
          id: "4",
          namaAnak: "Sari",
          namaIbu: "Umi",
          tanggalLahir: "2021-08-20",
          jenisKelamin: "perempuan",
          beratBadan: 9.8,
          tinggiBadan: 82.0,
          usia: 29,
          provinsi: "Jawa Barat",
          kabupaten: "Bandung",
          kecamatan: "Coblong",
          desa: "Dago",
          status: "normal",
          risiko: 20,
          tanggalPemeriksaan: "2024-01-12",
        },
      ];
      setData(mockData);
      setIsLoading(false);
    }, 1000);
  }, []);

  // Update dropdown options based on selected filters
  useEffect(() => {
    if (selectedProvinsi !== "all") {
      const uniqueKabupatens = [
        ...new Set(
          data
            .filter((d) => d.provinsi === selectedProvinsi)
            .map((d) => d.kabupaten)
        ),
      ];
      setKabupatens(uniqueKabupatens);
    } else {
      setKabupatens([]);
    }
    setSelectedKabupaten("all");
    setSelectedKecamatan("all");
    setSelectedDesa("all");
  }, [selectedProvinsi, data]);

  useEffect(() => {
    if (selectedKabupaten !== "all") {
      const uniqueKecamatans = [
        ...new Set(
          data
            .filter(
              (d) =>
                d.provinsi === selectedProvinsi &&
                d.kabupaten === selectedKabupaten
            )
            .map((d) => d.kecamatan)
        ),
      ];
      setKecamatans(uniqueKecamatans);
    } else {
      setKecamatans([]);
    }
    setSelectedKecamatan("all");
    setSelectedDesa("all");
  }, [selectedKabupaten, selectedProvinsi, data]);

  useEffect(() => {
    if (selectedKecamatan !== "all") {
      const uniqueDesas = [
        ...new Set(
          data
            .filter(
              (d) =>
                d.provinsi === selectedProvinsi &&
                d.kabupaten === selectedKabupaten &&
                d.kecamatan === selectedKecamatan
            )
            .map((d) => d.desa)
        ),
      ];
      setDesas(uniqueDesas);
    } else {
      setDesas([]);
    }
    setSelectedDesa("all");
  }, [selectedKecamatan, selectedKabupaten, selectedProvinsi, data]);

  const handleDownloadExcel = () => {
    // Simulate Excel download
    const csvContent = [
      [
        "No",
        "Nama Anak",
        "Nama Ibu",
        "Tanggal Lahir",
        "Jenis Kelamin",
        "Berat (kg)",
        "Tinggi (cm)",
        "Usia (bulan)",
        "Provinsi",
        "Kabupaten/Kota",
        "Kecamatan",
        "Desa",
        "Status",
        "Risiko (%)",
        "Tanggal Pemeriksaan",
      ],
      ...filteredData.map((item, index) => [
        index + 1,
        item.namaAnak,
        item.namaIbu,
        item.tanggalLahir,
        item.jenisKelamin === "laki-laki" ? "Laki-laki" : "Perempuan",
        item.beratBadan,
        item.tinggiBadan,
        item.usia,
        item.provinsi,
        item.kabupaten,
        item.kecamatan,
        item.desa,
        item.status === "normal"
          ? "Normal"
          : item.status === "berisiko"
          ? "Berisiko"
          : "Stunting",
        item.risiko,
        item.tanggalPemeriksaan,
      ]),
    ]
      .map((row) => row.join(","))
      .join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute(
      "download",
      `data-stunting-${new Date().toISOString().split("T")[0]}.csv`
    );
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setSuccessMessage("Data berhasil diunduh!");
    setTimeout(() => setSuccessMessage(null), 3000);
  };

  const filteredData = data.filter((item) => {
    const searchMatch =
      item.namaAnak.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.namaIbu.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.provinsi.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.kabupaten.toLowerCase().includes(searchTerm.toLowerCase());

    const provinsiMatch =
      selectedProvinsi === "all" || item.provinsi === selectedProvinsi;
    const kabupatenMatch =
      selectedKabupaten === "all" || item.kabupaten === selectedKabupaten;
    const kecamatanMatch =
      selectedKecamatan === "all" || item.kecamatan === selectedKecamatan;
    const desaMatch = selectedDesa === "all" || item.desa === selectedDesa;

    return (
      searchMatch &&
      provinsiMatch &&
      kabupatenMatch &&
      kecamatanMatch &&
      desaMatch
    );
  });

  // Prepare chart data
  const chartData = filteredData.map((item, index) => ({
    name: item.namaAnak,
    usia: item.usia,
    beratBadan: item.beratBadan,
    tinggiBadan: item.tinggiBadan,
    risiko: item.risiko,
    status: item.status,
    jenisKelamin: item.jenisKelamin,
  }));

  const uniqueProvinsis = [...new Set(data.map((d) => d.provinsi))];

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Kelola Data Stunting
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Kelola dan analisis data pemeriksaan stunting
          </p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isChartDialogOpen} onOpenChange={setIsChartDialogOpen}>
            <DialogTrigger asChild>
              <Button
                variant="outline"
                className="bg-blue-50 border-blue-200 text-blue-600 hover:bg-blue-100"
              >
                <BarChart3 className="mr-2 h-4 w-4" />
                Lihat Grafik WHO
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Grafik WHO - Semua Data</DialogTitle>
                <DialogDescription>
                  Visualisasi data pertumbuhan anak berdasarkan standar WHO
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold mb-4">Berat Badan vs Usia</h3>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <ScatterChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis
                          dataKey="usia"
                          label={{
                            value: "Usia (bulan)",
                            position: "insideBottom",
                            offset: -10,
                          }}
                        />
                        <YAxis
                          label={{
                            value: "Berat (kg)",
                            angle: -90,
                            position: "insideLeft",
                          }}
                        />
                        <Tooltip
                          formatter={(value, name) => [
                            value,
                            name === "beratBadan" ? "Berat Badan (kg)" : name,
                          ]}
                        />
                        <Scatter
                          dataKey="beratBadan"
                          fill={(entry) =>
                            entry.status === "normal"
                              ? "#22c55e"
                              : entry.status === "berisiko"
                              ? "#eab308"
                              : "#ef4444"
                          }
                        />
                      </ScatterChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-4">
                    Berat Badan vs Jenis Kelamin
                  </h3>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <ScatterChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis
                          dataKey="jenisKelamin"
                          label={{
                            value: "Jenis Kelamin",
                            position: "insideBottom",
                            offset: -10,
                          }}
                        />
                        <YAxis
                          label={{
                            value: "Berat (kg)",
                            angle: -90,
                            position: "insideLeft",
                          }}
                        />
                        <Tooltip
                          formatter={(value, name) => [
                            value,
                            name === "beratBadan" ? "Berat Badan (kg)" : name,
                          ]}
                        />
                        <Scatter
                          dataKey="beratBadan"
                          fill={(entry) =>
                            entry.status === "normal"
                              ? "#22c55e"
                              : entry.status === "berisiko"
                              ? "#eab308"
                              : "#ef4444"
                          }
                        />
                      </ScatterChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-4">Tinggi Badan vs Usia</h3>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <ScatterChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis
                          dataKey="usia"
                          label={{
                            value: "Usia (bulan)",
                            position: "insideBottom",
                            offset: -10,
                          }}
                        />
                        <YAxis
                          label={{
                            value: "Tinggi (cm)",
                            angle: -90,
                            position: "insideLeft",
                          }}
                        />
                        <Tooltip
                          formatter={(value, name) => [
                            value,
                            name === "tinggiBadan" ? "Tinggi Badan (cm)" : name,
                          ]}
                        />
                        <Scatter
                          dataKey="tinggiBadan"
                          fill={(entry) =>
                            entry.status === "normal"
                              ? "#22c55e"
                              : entry.status === "berisiko"
                              ? "#eab308"
                              : "#ef4444"
                          }
                        />
                      </ScatterChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-4">
                    Tinggi Badan vs Jenis Kelamin
                  </h3>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <ScatterChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis
                          dataKey="jenisKelamin"
                          label={{
                            value: "Jenis Kelamin",
                            position: "insideBottom",
                            offset: -10,
                          }}
                        />
                        <YAxis
                          label={{
                            value: "Tinggi (cm)",
                            angle: -90,
                            position: "insideLeft",
                          }}
                        />
                        <Tooltip
                          formatter={(value, name) => [
                            value,
                            name === "tinggiBadan" ? "Tinggi Badan (cm)" : name,
                          ]}
                        />
                        <Scatter
                          dataKey="tinggiBadan"
                          fill={(entry) =>
                            entry.status === "normal"
                              ? "#22c55e"
                              : entry.status === "berisiko"
                              ? "#eab308"
                              : "#ef4444"
                          }
                        />
                      </ScatterChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Button
            onClick={handleDownloadExcel}
            className="bg-green-600 hover:bg-green-700 text-white"
          >
            <Download className="mr-2 h-4 w-4" />
            Download Excel
          </Button>
        </div>
      </div>

      {/* Alert Messages */}
      {successMessage && (
        <Alert className="bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-900 shadow-sm">
          <AlertTitle className="text-green-800 dark:text-green-200">
            Berhasil
          </AlertTitle>
          <AlertDescription className="text-green-700 dark:text-green-300">
            {successMessage}
          </AlertDescription>
        </Alert>
      )}

      {errorMessage && (
        <Alert variant="destructive" className="shadow-sm">
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{errorMessage}</AlertDescription>
        </Alert>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Data</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{filteredData.length}</div>
            <p className="text-xs text-muted-foreground">
              dari {data.length} total data
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Status Normal</CardTitle>
            <div className="h-3 w-3 bg-green-500 rounded-full"></div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {filteredData.filter((d) => d.status === "normal").length}
            </div>
            <p className="text-xs text-muted-foreground">
              {(
                (filteredData.filter((d) => d.status === "normal").length /
                  filteredData.length) *
                  100 || 0
              ).toFixed(1)}
              %
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Berisiko</CardTitle>
            <div className="h-3 w-3 bg-yellow-500 rounded-full"></div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {filteredData.filter((d) => d.status === "berisiko").length}
            </div>
            <p className="text-xs text-muted-foreground">
              {(
                (filteredData.filter((d) => d.status === "berisiko").length /
                  filteredData.length) *
                  100 || 0
              ).toFixed(1)}
              %
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Stunting</CardTitle>
            <div className="h-3 w-3 bg-red-500 rounded-full"></div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {filteredData.filter((d) => d.status === "stunting").length}
            </div>
            <p className="text-xs text-muted-foreground">
              {(
                (filteredData.filter((d) => d.status === "stunting").length /
                  filteredData.length) *
                  100 || 0
              ).toFixed(1)}
              %
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filters Section */}
      <Card className="shadow-sm">
        <CardContent className="p-6">
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <Filter className="h-4 w-4 text-gray-500" />
              <span className="font-medium text-gray-700 dark:text-gray-300">
                Filter Data
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Cari nama anak/ibu..."
                  className="pl-10 focus:ring-2 focus:ring-purple-500"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <Select
                value={selectedProvinsi}
                onValueChange={setSelectedProvinsi}
              >
                <SelectTrigger className="focus:ring-2 focus:ring-purple-500">
                  <SelectValue placeholder="Semua Provinsi" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Provinsi</SelectItem>
                  {uniqueProvinsis.map((provinsi) => (
                    <SelectItem key={provinsi} value={provinsi}>
                      {provinsi}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select
                value={selectedKabupaten}
                onValueChange={setSelectedKabupaten}
                disabled={selectedProvinsi === "all"}
              >
                <SelectTrigger className="focus:ring-2 focus:ring-purple-500">
                  <SelectValue placeholder="Semua Kabupaten" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Kabupaten</SelectItem>
                  {kabupatens.map((kabupaten) => (
                    <SelectItem key={kabupaten} value={kabupaten}>
                      {kabupaten}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select
                value={selectedKecamatan}
                onValueChange={setSelectedKecamatan}
                disabled={selectedKabupaten === "all"}
              >
                <SelectTrigger className="focus:ring-2 focus:ring-purple-500">
                  <SelectValue placeholder="Semua Kecamatan" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Kecamatan</SelectItem>
                  {kecamatans.map((kecamatan) => (
                    <SelectItem key={kecamatan} value={kecamatan}>
                      {kecamatan}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select
                value={selectedDesa}
                onValueChange={setSelectedDesa}
                disabled={selectedKecamatan === "all"}
              >
                <SelectTrigger className="focus:ring-2 focus:ring-purple-500">
                  <SelectValue placeholder="Semua Desa" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Desa</SelectItem>
                  {desas.map((desa) => (
                    <SelectItem key={desa} value={desa}>
                      {desa}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Button
                variant="outline"
                onClick={() => {
                  setSearchTerm("");
                  setSelectedProvinsi("all");
                  setSelectedKabupaten("all");
                  setSelectedKecamatan("all");
                  setSelectedDesa("all");
                }}
                className="w-full"
              >
                Reset Filter
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Data Table */}
      <Card className="shadow-sm">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50 dark:bg-gray-800/50">
                  <TableHead className="font-semibold">No</TableHead>
                  <TableHead className="font-semibold">Nama Anak</TableHead>
                  <TableHead className="font-semibold">Nama Ibu</TableHead>
                  <TableHead className="font-semibold">Tanggal Lahir</TableHead>
                  <TableHead className="font-semibold">Jenis Kelamin</TableHead>
                  <TableHead className="font-semibold">Berat (kg)</TableHead>
                  <TableHead className="font-semibold">Tinggi (cm)</TableHead>
                  <TableHead className="font-semibold">Provinsi</TableHead>
                  <TableHead className="font-semibold">
                    Kabupaten/Kota
                  </TableHead>
                  <TableHead className="font-semibold">Kecamatan</TableHead>
                  <TableHead className="font-semibold">Desa</TableHead>
                  <TableHead className="font-semibold">Status</TableHead>
                  <TableHead className="font-semibold">Risiko (%)</TableHead>
                  <TableHead className="font-semibold">
                    Tanggal Pengecekan
                  </TableHead>
                  <TableHead className="font-semibold">WHO Chart</TableHead>
                  <TableHead className="text-right font-semibold">
                    Aksi
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={15} className="text-center py-12">
                      <div className="flex flex-col items-center space-y-3">
                        <Loader2 className="h-8 w-8 animate-spin text-purple-500" />
                        <span className="text-gray-500 dark:text-gray-400">
                          Memuat data...
                        </span>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : filteredData.length > 0 ? (
                  filteredData.map((item, index) => (
                    <TableRow
                      key={item.id}
                      className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors"
                    >
                      <TableCell className="font-medium">{index + 1}</TableCell>
                      <TableCell className="font-medium">
                        {item.namaAnak}
                      </TableCell>
                      <TableCell>{item.namaIbu}</TableCell>
                      <TableCell>{item.tanggalLahir}</TableCell>
                      <TableCell>
                        {item.jenisKelamin === "laki-laki"
                          ? "Laki-laki"
                          : "Perempuan"}
                      </TableCell>
                      <TableCell>{item.beratBadan}</TableCell>
                      <TableCell>{item.tinggiBadan}</TableCell>
                      <TableCell>{item.provinsi}</TableCell>
                      <TableCell>{item.kabupaten}</TableCell>
                      <TableCell>{item.kecamatan}</TableCell>
                      <TableCell>{item.desa}</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            item.status === "normal"
                              ? "bg-green-50 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-300 dark:border-green-800"
                              : item.status === "berisiko"
                              ? "bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-900/20 dark:text-yellow-300 dark:border-yellow-800"
                              : "bg-red-50 text-red-700 border-red-200 dark:bg-red-900/20 dark:text-red-300 dark:border-red-800"
                          }
                        >
                          {item.status === "normal"
                            ? "Normal"
                            : item.status === "berisiko"
                            ? "Berisiko"
                            : "Stunting"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <span
                          className={
                            item.risiko <= 25
                              ? "text-green-600"
                              : item.risiko <= 50
                              ? "text-yellow-600"
                              : "text-red-600"
                          }
                        >
                          {item.risiko}%
                        </span>
                      </TableCell>
                      <TableCell>{item.tanggalPemeriksaan}</TableCell>
                      <TableCell>
                        <Dialog
                          open={
                            selectedData?.id === item.id && isChartDialogOpen
                          }
                          onOpenChange={(open) => {
                            setIsChartDialogOpen(open);
                            if (!open && selectedData?.id === item.id)
                              setSelectedData(null);
                          }}
                        >
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedData(item);
                                setIsChartDialogOpen(true);
                              }}
                              className="text-blue-600 hover:text-blue-700"
                            >
                              <BarChart3 className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
                            <DialogHeader>
                              <DialogTitle>
                                Grafik WHO - {item.namaAnak}
                              </DialogTitle>
                              <DialogDescription>
                                Visualisasi data pertumbuhan anak berdasarkan
                                standar WHO
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-6">
                              <div>
                                <h3 className="font-semibold mb-4">
                                  Berat Badan vs Usia
                                </h3>
                                <div className="h-[300px]">
                                  <ResponsiveContainer
                                    width="100%"
                                    height="100%"
                                  >
                                    <ScatterChart data={[item]}>
                                      <CartesianGrid strokeDasharray="3 3" />
                                      <XAxis
                                        dataKey="usia"
                                        label={{
                                          value: "Usia (bulan)",
                                          position: "insideBottom",
                                          offset: -10,
                                        }}
                                        type="number"
                                        domain={[0, "dataMax"]}
                                      />
                                      <YAxis
                                        label={{
                                          value: "Berat (kg)",
                                          angle: -90,
                                          position: "insideLeft",
                                        }}
                                        type="number"
                                        domain={[0, "dataMax"]}
                                      />
                                      <Tooltip
                                        formatter={(value, name) => [
                                          value,
                                          name === "beratBadan"
                                            ? "Berat Badan (kg)"
                                            : name,
                                        ]}
                                      />
                                      <Scatter
                                        dataKey="beratBadan"
                                        fill={
                                          item.status === "normal"
                                            ? "#22c55e"
                                            : item.status === "berisiko"
                                            ? "#eab308"
                                            : "#ef4444"
                                        }
                                      />
                                    </ScatterChart>
                                  </ResponsiveContainer>
                                </div>
                                <p className="text-sm text-gray-500">
                                  Grafik ini membandingkan berat badan anak
                                  dengan usianya. Warna hijau menunjukkan berat
                                  badan normal, kuning berisiko, dan merah
                                  stunting.
                                </p>
                              </div>

                              <div>
                                <h3 className="font-semibold mb-4">
                                  Tinggi Badan vs Usia
                                </h3>
                                <div className="h-[300px]">
                                  <ResponsiveContainer
                                    width="100%"
                                    height="100%"
                                  >
                                    <ScatterChart data={[item]}>
                                      <CartesianGrid strokeDasharray="3 3" />
                                      <XAxis
                                        dataKey="usia"
                                        label={{
                                          value: "Usia (bulan)",
                                          position: "insideBottom",
                                          offset: -10,
                                        }}
                                        type="number"
                                        domain={[0, "dataMax"]}
                                      />
                                      <YAxis
                                        label={{
                                          value: "Tinggi (cm)",
                                          angle: -90,
                                          position: "insideLeft",
                                        }}
                                        type="number"
                                        domain={[0, "dataMax"]}
                                      />
                                      <Tooltip
                                        formatter={(value, name) => [
                                          value,
                                          name === "tinggiBadan"
                                            ? "Tinggi Badan (cm)"
                                            : name,
                                        ]}
                                      />
                                      <Scatter
                                        dataKey="tinggiBadan"
                                        fill={
                                          item.status === "normal"
                                            ? "#22c55e"
                                            : item.status === "berisiko"
                                            ? "#eab308"
                                            : "#ef4444"
                                        }
                                      />
                                    </ScatterChart>
                                  </ResponsiveContainer>
                                </div>
                                <p className="text-sm text-gray-500">
                                  Grafik ini membandingkan tinggi badan anak
                                  dengan usianya. Warna hijau menunjukkan tinggi
                                  badan normal, kuning berisiko, dan merah
                                  stunting.
                                </p>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Dialog
                            open={
                              isDetailDialogOpen && selectedData?.id === item.id
                            }
                            onOpenChange={(open) => {
                              setIsDetailDialogOpen(open);
                              if (!open) setSelectedData(null);
                            }}
                          >
                            <DialogTrigger asChild>
                              <Button
                                variant="outline"
                                size="icon"
                                onClick={() => setSelectedData(item)}
                                className="hover:bg-blue-50 hover:border-blue-200 hover:text-blue-600"
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-2xl">
                              <DialogHeader>
                                <DialogTitle>Detail Data Stunting</DialogTitle>
                                <DialogDescription>
                                  Informasi lengkap hasil pemeriksaan
                                </DialogDescription>
                              </DialogHeader>
                              {selectedData && (
                                <div className="space-y-4">
                                  <div className="grid grid-cols-2 gap-4">
                                    <div>
                                      <Label className="font-medium">
                                        Nama Anak
                                      </Label>
                                      <p>{selectedData.namaAnak}</p>
                                    </div>
                                    <div>
                                      <Label className="font-medium">
                                        Nama Ibu
                                      </Label>
                                      <p>{selectedData.namaIbu}</p>
                                    </div>
                                    <div>
                                      <Label className="font-medium">
                                        Tanggal Lahir
                                      </Label>
                                      <p>{selectedData.tanggalLahir}</p>
                                    </div>
                                    <div>
                                      <Label className="font-medium">
                                        Usia
                                      </Label>
                                      <p>{selectedData.usia} bulan</p>
                                    </div>
                                    <div>
                                      <Label className="font-medium">
                                        Jenis Kelamin
                                      </Label>
                                      <p>
                                        {selectedData.jenisKelamin ===
                                        "laki-laki"
                                          ? "Laki-laki"
                                          : "Perempuan"}
                                      </p>
                                    </div>
                                    <div>
                                      <Label className="font-medium">
                                        Berat Badan
                                      </Label>
                                      <p>{selectedData.beratBadan} kg</p>
                                    </div>
                                    <div>
                                      <Label className="font-medium">
                                        Tinggi Badan
                                      </Label>
                                      <p>{selectedData.tinggiBadan} cm</p>
                                    </div>
                                    <div>
                                      <Label className="font-medium">
                                        Status
                                      </Label>
                                      <Badge
                                        className={
                                          selectedData.status === "normal"
                                            ? "bg-green-100 text-green-800"
                                            : selectedData.status === "berisiko"
                                            ? "bg-yellow-100 text-yellow-800"
                                            : "bg-red-100 text-red-800"
                                        }
                                      >
                                        {selectedData.status === "normal"
                                          ? "Normal"
                                          : selectedData.status === "berisiko"
                                          ? "Berisiko"
                                          : "Stunting"}
                                      </Badge>
                                    </div>
                                  </div>
                                  <div>
                                    <Label className="font-medium">
                                      Alamat Lengkap
                                    </Label>
                                    <p>
                                      {selectedData.desa},{" "}
                                      {selectedData.kecamatan},{" "}
                                      {selectedData.kabupaten},{" "}
                                      {selectedData.provinsi}
                                    </p>
                                  </div>
                                  <div>
                                    <Label className="font-medium">
                                      Tingkat Risiko
                                    </Label>
                                    <div className="flex items-center gap-2">
                                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                                        <div
                                          className={`h-2 rounded-full ${
                                            selectedData.risiko <= 25
                                              ? "bg-green-500"
                                              : selectedData.risiko <= 50
                                              ? "bg-yellow-500"
                                              : "bg-red-500"
                                          }`}
                                          style={{
                                            width: `${selectedData.risiko}%`,
                                          }}
                                        ></div>
                                      </div>
                                      <span className="font-medium">
                                        {selectedData.risiko}%
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              )}
                            </DialogContent>
                          </Dialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={15} className="text-center py-12">
                      <div className="flex flex-col items-center space-y-3">
                        <Users className="h-12 w-12 text-gray-400" />
                        <div>
                          <p className="text-gray-500 dark:text-gray-400 font-medium">
                            Tidak ada data yang ditemukan
                          </p>
                          <p className="text-sm text-gray-400 dark:text-gray-500">
                            Coba ubah filter atau kata kunci pencarian
                          </p>
                        </div>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
