"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Calendar,
  Clock,
  Heart,
  Share2,
  BookOpen,
  Eye,
  Lightbulb,
} from "lucide-react";
import { motion } from "framer-motion";

interface Article {
  id: number;
  title: string;
  excerpt: string;
  content: string;
  image: string;
  date: string;
  category: string;
  likes: number;
  views: number;
  isPopular: boolean;
  tableOfContents: string[];
  importantPoints: string[];
}

interface ArticleContentProps {
  article: Article;
  readingTime: number;
  relatedArticles: Article[];
}

export function ArticleContent({
  article,
  readingTime,
  relatedArticles,
}: ArticleContentProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(article.likes);

  const handleLike = () => {
    setIsLiked(!isLiked);
    setLikesCount((prev) => (isLiked ? prev - 1 : prev + 1));
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: article.title,
        text: article.excerpt,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert("Link berhasil disalin!");
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header Article */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8"
      >
        <div className="flex flex-wrap items-center gap-3 mb-4">
          <Badge className="bg-[#317BC4] hover:bg-[#2A6CB0] text-white px-3 py-1 rounded-full">
            {article.category}
          </Badge>
          {article.isPopular && (
            <Badge className="bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 rounded-full">
              Populer
            </Badge>
          )}
        </div>

        <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 text-gray-900 dark:text-white leading-tight">
          {article.title}
        </h1>

        <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 dark:text-gray-400 mb-6">
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            <span>{article.date}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            <span>{readingTime} menit baca</span>
          </div>
          <div className="flex items-center gap-2">
            <Eye className="h-4 w-4" />
            <span>{article.views} views</span>
          </div>
        </div>

        <p className="text-lg text-gray-600 dark:text-gray-300 mb-8 leading-relaxed">
          {article.excerpt}
        </p>

        {/* Action Buttons */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            onClick={handleLike}
            variant={isLiked ? "default" : "outline"}
            className={`flex items-center gap-2 rounded-full ${
              isLiked
                ? "bg-red-500 hover:bg-red-600 text-white"
                : "border-red-500 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20"
            }`}
          >
            <Heart className={`h-4 w-4 ${isLiked ? "fill-current" : ""}`} />
            <span>{likesCount}</span>
          </Button>
          <Button
            onClick={handleShare}
            variant="outline"
            className="flex items-center gap-2 rounded-full border-[#317BC4] text-[#317BC4] hover:bg-[#D7EBFC] dark:border-blue-400 dark:text-blue-400"
          >
            <Share2 className="h-4 w-4" />
            <span>Bagikan</span>
          </Button>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="lg:col-span-3"
        >
          {/* Featured Image */}
          <div className="relative h-64 md:h-96 w-full mb-8 rounded-2xl overflow-hidden shadow-lg">
            <Image
              src={article.image || "/placeholder.svg"}
              alt={article.title}
              fill
              className="object-cover"
            />
          </div>

          {/* Article Content */}
          <div className="prose prose-lg max-w-none dark:prose-invert mb-8">
            <div
              dangerouslySetInnerHTML={{ __html: article.content }}
              className="[&>h2]:text-2xl [&>h2]:font-bold [&>h2]:text-gray-900 [&>h2]:dark:text-white [&>h2]:mb-4 [&>h2]:mt-8 [&>p]:text-gray-700 [&>p]:dark:text-gray-300 [&>p]:leading-relaxed [&>p]:mb-6"
            />
          </div>

          {/* Important Points */}
          {article.importantPoints && article.importantPoints.length > 0 && (
            <Card className="mb-8 border-l-4 border-l-[#317BC4] bg-[#F8FAFC] dark:bg-gray-800/50">
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Lightbulb className="h-5 w-5 text-[#317BC4]" />
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                    Poin-Poin Penting
                  </h3>
                </div>
                <ul className="space-y-2">
                  {article.importantPoints.map((point, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-[#317BC4] rounded-full mt-2 flex-shrink-0" />
                      <span className="text-gray-700 dark:text-gray-300">
                        {point}
                      </span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {/* Conclusion */}
          <div className="bg-gradient-to-r from-[#317BC4]/10 to-[#64B5F6]/10 dark:from-blue-900/20 dark:to-blue-800/20 rounded-2xl p-6 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              Kesimpulan
            </h2>
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
              Artikel ini memberikan pemahaman komprehensif tentang{" "}
              {article.title.toLowerCase()}. Dengan menerapkan informasi yang
              telah disampaikan, diharapkan dapat membantu dalam upaya
              pencegahan stunting dan mendukung pertumbuhan optimal anak.
            </p>
          </div>
        </motion.div>

        {/* Sidebar */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="lg:col-span-1"
        >
          {/* Table of Contents */}
          {article.tableOfContents && article.tableOfContents.length > 0 && (
            <Card className="mb-6 sticky top-4">
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-4">
                  <BookOpen className="h-5 w-5 text-[#317BC4]" />
                  <h3 className="font-semibold text-gray-900 dark:text-white">
                    Daftar Isi
                  </h3>
                </div>
                <nav className="space-y-2">
                  {article.tableOfContents.map((item, index) => (
                    <a
                      key={index}
                      href={`#${item.toLowerCase().replace(/\s+/g, "-")}`}
                      className="block text-sm text-gray-600 dark:text-gray-400 hover:text-[#317BC4] dark:hover:text-blue-400 transition-colors py-1 border-l-2 border-transparent hover:border-[#317BC4] pl-3"
                    >
                      {item}
                    </a>
                  ))}
                </nav>
              </CardContent>
            </Card>
          )}

          {/* Related Articles */}
          {relatedArticles && relatedArticles.length > 0 && (
            <Card>
              <CardContent className="p-6">
                <h3 className="font-semibold text-gray-900 dark:text-white mb-4">
                  Artikel Terkait
                </h3>
                <div className="space-y-4">
                  {relatedArticles.map((relatedArticle) => (
                    <Link
                      key={relatedArticle.id}
                      href={`/edukasi/${relatedArticle.id}`}
                      className="block group"
                    >
                      <div className="flex gap-3">
                        <div className="relative w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                          <Image
                            src={relatedArticle.image || "/placeholder.svg"}
                            alt={relatedArticle.title}
                            fill
                            className="object-cover group-hover:scale-105 transition-transform"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="text-sm font-medium text-gray-900 dark:text-white line-clamp-2 group-hover:text-[#317BC4] dark:group-hover:text-blue-400 transition-colors">
                            {relatedArticle.title}
                          </h4>
                          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                            {relatedArticle.date}
                          </p>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </motion.div>
      </div>
    </div>
  );
}
