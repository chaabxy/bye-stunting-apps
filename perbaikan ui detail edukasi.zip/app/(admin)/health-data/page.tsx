"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Textarea } from "@/components/ui/textarea"
import { useEffect, useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Plus, Search, Database, LinkIcon, Loader2, ExternalLink, Edit, Trash2 } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"

interface HealthData {
  id: string
  title: string
  description: string
  source: string
  category: string
  url: string
  accessLevel: string
  lastUpdated: string
}

const HealthDataPage = () => {
  const [healthData, setHealthData] = useState<HealthData[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [currentData, setCurrentData] = useState<HealthData | null>(null)
  const [newData, setNewData] = useState({
    title: "",
    description: "",
    source: "",
    category: "",
    url: "",
    accessLevel: "public",
  })
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [categories, setCategories] = useState<string[]>([])
  const [successMessage, setSuccessMessage] = useState<string | null>(null)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  useEffect(() => {
    // Simulate fetching data from an API
    const fetchData = async () => {
      setIsLoading(true)
      try {
        // Replace this with your actual API endpoint
        const response = await new Promise((resolve) =>
          setTimeout(() => {
            resolve([
              {
                id: "1",
                title: "Data Vaksinasi COVID-19",
                description: "Data terbaru mengenai vaksinasi COVID-19 di Indonesia",
                source: "Kementerian Kesehatan",
                category: "Statistik",
                url: "https://example.com/api/vaksincovid",
                accessLevel: "public",
                lastUpdated: "2023-11-15",
              },
              {
                id: "2",
                title: "Panduan Gizi Seimbang",
                description: "Informasi mengenai panduan gizi seimbang untuk masyarakat",
                source: "Dinas Kesehatan DKI Jakarta",
                category: "Panduan",
                url: "https://example.com/api/giziseimbang",
                accessLevel: "public",
                lastUpdated: "2023-11-10",
              },
              {
                id: "3",
                title: "Data Penyakit Tidak Menular",
                description: "Data penyakit tidak menular di wilayah Jawa Barat",
                source: "Dinas Kesehatan Jawa Barat",
                category: "Statistik",
                url: "https://example.com/api/ptm",
                accessLevel: "restricted",
                lastUpdated: "2023-11-05",
              },
            ])
          }, 1500),
        )
        const data = response as HealthData[]
        setHealthData(data)

        // Extract unique categories
        const uniqueCategories = [...new Set(data.map((item) => item.category))]
        setCategories(uniqueCategories)
      } catch (error) {
        console.error("Error fetching data:", error)
        setErrorMessage("Gagal memuat data kesehatan.")
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [])

  const handleAddHealthData = () => {
    // Simulate adding new health data
    const newId = Math.random().toString(36).substring(7) // Generate a random ID
    const newHealthData = {
      id: newId,
      ...newData,
      lastUpdated: new Date().toLocaleDateString(),
    }
    setHealthData([...healthData, newHealthData])
    setNewData({
      title: "",
      description: "",
      source: "",
      category: "",
      url: "",
      accessLevel: "public",
    })
    setIsAddDialogOpen(false)
    setSuccessMessage("Data kesehatan berhasil ditambahkan.")
    setTimeout(() => setSuccessMessage(null), 3000) // Clear message after 3 seconds
  }

  const handleEditHealthData = () => {
    if (!currentData) return

    // Simulate updating health data
    const updatedData = healthData.map((item) =>
      item.id === currentData.id ? { ...currentData, lastUpdated: new Date().toLocaleDateString() } : item,
    )
    setHealthData(updatedData)
    setCurrentData(null)
    setIsEditDialogOpen(false)
    setSuccessMessage("Data kesehatan berhasil diperbarui.")
    setTimeout(() => setSuccessMessage(null), 3000) // Clear message after 3 seconds
  }

  const handleDeleteHealthData = () => {
    if (!currentData) return

    // Simulate deleting health data
    const updatedData = healthData.filter((item) => item.id !== currentData.id)
    setHealthData(updatedData)
    setCurrentData(null)
    setIsDeleteDialogOpen(false)
    setSuccessMessage("Data kesehatan berhasil dihapus.")
    setTimeout(() => setSuccessMessage(null), 3000) // Clear message after 3 seconds
  }

  const filteredData = healthData.filter((item) => {
    const searchTermMatch =
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.source.toLowerCase().includes(searchTerm.toLowerCase())
    const categoryMatch = selectedCategory === "all" || item.category === selectedCategory
    return searchTermMatch && categoryMatch
  })

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Kelola Data Kesehatan</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            Kelola integrasi API dan data dari Dinas Kesehatan dan lembaga terkait
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white shadow-lg hover:shadow-xl transition-all duration-200">
              <Plus className="mr-2 h-4 w-4" /> Tambah Data
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-xl font-semibold">Tambah Data Kesehatan Baru</DialogTitle>
              <DialogDescription>Isi form berikut untuk menambahkan data kesehatan baru ke platform</DialogDescription>
            </DialogHeader>
            <div className="grid gap-6 py-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="title" className="text-sm font-medium">
                    Judul Data
                  </Label>
                  <Input
                    id="title"
                    value={newData.title}
                    onChange={(e) => setNewData({ ...newData, title: e.target.value })}
                    placeholder="Masukkan judul data"
                    className="focus:ring-2 focus:ring-green-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="source" className="text-sm font-medium">
                    Sumber
                  </Label>
                  <Input
                    id="source"
                    value={newData.source}
                    onChange={(e) => setNewData({ ...newData, source: e.target.value })}
                    placeholder="Masukkan sumber data (mis. Kementerian Kesehatan)"
                    className="focus:ring-2 focus:ring-green-500"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="category" className="text-sm font-medium">
                  Kategori
                </Label>
                <Input
                  id="category"
                  value={newData.category}
                  onChange={(e) => setNewData({ ...newData, category: e.target.value })}
                  placeholder="Masukkan kategori (mis. Statistik, Panduan)"
                  className="focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description" className="text-sm font-medium">
                  Deskripsi
                </Label>
                <Textarea
                  id="description"
                  value={newData.description}
                  onChange={(e) => setNewData({ ...newData, description: e.target.value })}
                  placeholder="Masukkan deskripsi data"
                  rows={3}
                  className="focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="url" className="text-sm font-medium">
                  URL API
                </Label>
                <Input
                  id="url"
                  value={newData.url}
                  onChange={(e) => setNewData({ ...newData, url: e.target.value })}
                  placeholder="Masukkan URL API"
                  className="focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="accessLevel" className="text-sm font-medium">
                  Level Akses
                </Label>
                <Select
                  value={newData.accessLevel}
                  onValueChange={(value) => setNewData({ ...newData, accessLevel: value })}
                >
                  <SelectTrigger id="accessLevel" className="focus:ring-2 focus:ring-green-500">
                    <SelectValue placeholder="Pilih level akses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="public">Publik</SelectItem>
                    <SelectItem value="restricted">Terbatas</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Batal
              </Button>
              <Button
                onClick={handleAddHealthData}
                className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800"
              >
                Simpan Data
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Alert Messages */}
      {successMessage && (
        <Alert className="bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-900 shadow-sm">
          <AlertTitle className="text-green-800 dark:text-green-200">Berhasil</AlertTitle>
          <AlertDescription className="text-green-700 dark:text-green-300">{successMessage}</AlertDescription>
        </Alert>
      )}

      {errorMessage && (
        <Alert variant="destructive" className="shadow-sm">
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{errorMessage}</AlertDescription>
        </Alert>
      )}

      {/* Filters Section */}
      <Card className="shadow-sm">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="relative w-full md:w-80">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Cari data kesehatan..."
                className="pl-10 focus:ring-2 focus:ring-green-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-full md:w-48 focus:ring-2 focus:ring-green-500">
                <SelectValue placeholder="Filter kategori" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Kategori</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200 dark:border-green-800">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center space-x-2">
              <Database className="h-5 w-5 text-green-600 dark:text-green-400" />
              <span>Total Data Kesehatan</span>
            </CardTitle>
            <CardDescription>Jumlah total data kesehatan yang terintegrasi</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold text-green-600 dark:text-green-400">{healthData.length}</div>
            <p className="text-sm text-green-700 dark:text-green-300 mt-1">Data tersedia</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 border-blue-200 dark:border-blue-800">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center space-x-2">
              <LinkIcon className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              <span>Sumber Data</span>
            </CardTitle>
            <CardDescription>Jumlah sumber data yang terintegrasi</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold text-blue-600 dark:text-blue-400">
              {new Set(healthData.map((item) => item.source)).size}
            </div>
            <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">Sumber aktif</p>
          </CardContent>
        </Card>
      </div>

      {/* Health Data Table */}
      <Card className="shadow-sm">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50 dark:bg-gray-800/50">
                <TableHead className="font-semibold">Judul</TableHead>
                <TableHead className="font-semibold">Sumber</TableHead>
                <TableHead className="font-semibold">Kategori</TableHead>
                <TableHead className="font-semibold">Level Akses</TableHead>
                <TableHead className="font-semibold">Terakhir Diperbarui</TableHead>
                <TableHead className="text-right font-semibold">Aksi</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12">
                    <div className="flex flex-col items-center space-y-3">
                      <Loader2 className="h-8 w-8 animate-spin text-green-500" />
                      <span className="text-gray-500 dark:text-gray-400">Memuat data kesehatan...</span>
                    </div>
                  </TableCell>
                </TableRow>
              ) : healthData.length > 0 ? (
                healthData.map((item) => (
                  <TableRow key={item.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                    <TableCell className="font-medium py-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-green-600 rounded-lg flex items-center justify-center">
                          <LinkIcon className="h-5 w-5 text-white" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">{item.title}</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400 truncate max-w-xs">
                            {item.description}
                          </p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-gray-600 dark:text-gray-400">{item.source}</TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className="bg-green-50 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-300 dark:border-green-800"
                      >
                        {item.category}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={item.accessLevel === "public" ? "secondary" : "outline"}
                        className={
                          item.accessLevel === "restricted"
                            ? "border-amber-500 text-amber-600 bg-amber-50 dark:bg-amber-900/20 dark:text-amber-400 dark:border-amber-700"
                            : ""
                        }
                      >
                        {item.accessLevel === "public" ? "Publik" : "Terbatas"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-gray-600 dark:text-gray-400">{item.lastUpdated}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          asChild
                          className="hover:bg-blue-50 hover:border-blue-200 hover:text-blue-600 dark:hover:bg-blue-900/20"
                        >
                          <a href={item.url} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </Button>
                        {/* Edit Dialog */}
                        <Dialog
                          open={isEditDialogOpen && currentData?.id === item.id}
                          onOpenChange={(open) => {
                            setIsEditDialogOpen(open)
                            if (!open) setCurrentData(null)
                          }}
                        >
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => setCurrentData(item)}
                              className="hover:bg-green-50 hover:border-green-200 hover:text-green-600 dark:hover:bg-green-900/20"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
                            <DialogHeader>
                              <DialogTitle className="text-xl font-semibold">Edit Data Kesehatan</DialogTitle>
                              <DialogDescription>Edit informasi data kesehatan yang sudah ada</DialogDescription>
                            </DialogHeader>
                            {currentData && (
                              <div className="grid gap-6 py-4">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  <div className="space-y-2">
                                    <Label htmlFor="edit-title" className="text-sm font-medium">
                                      Judul Data
                                    </Label>
                                    <Input
                                      id="edit-title"
                                      value={currentData.title}
                                      onChange={(e) => setCurrentData({ ...currentData, title: e.target.value })}
                                      className="focus:ring-2 focus:ring-green-500"
                                    />
                                  </div>
                                  <div className="space-y-2">
                                    <Label htmlFor="edit-source" className="text-sm font-medium">
                                      Sumber
                                    </Label>
                                    <Input
                                      id="edit-source"
                                      value={currentData.source}
                                      onChange={(e) => setCurrentData({ ...currentData, source: e.target.value })}
                                      className="focus:ring-2 focus:ring-green-500"
                                    />
                                  </div>
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="edit-category" className="text-sm font-medium">
                                    Kategori
                                  </Label>
                                  <Input
                                    id="edit-category"
                                    value={currentData.category}
                                    onChange={(e) => setCurrentData({ ...currentData, category: e.target.value })}
                                    className="focus:ring-2 focus:ring-green-500"
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="edit-description" className="text-sm font-medium">
                                    Deskripsi
                                  </Label>
                                  <Textarea
                                    id="edit-description"
                                    value={currentData.description}
                                    onChange={(e) => setCurrentData({ ...currentData, description: e.target.value })}
                                    rows={3}
                                    className="focus:ring-2 focus:ring-green-500"
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="edit-url" className="text-sm font-medium">
                                    URL API
                                  </Label>
                                  <Input
                                    id="edit-url"
                                    value={currentData.url}
                                    onChange={(e) => setCurrentData({ ...currentData, url: e.target.value })}
                                    className="focus:ring-2 focus:ring-green-500"
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="edit-accessLevel" className="text-sm font-medium">
                                    Level Akses
                                  </Label>
                                  <Select
                                    value={currentData.accessLevel}
                                    onValueChange={(value) => setCurrentData({ ...currentData, accessLevel: value })}
                                  >
                                    <SelectTrigger id="edit-accessLevel" className="focus:ring-2 focus:ring-green-500">
                                      <SelectValue placeholder="Pilih level akses" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="public">Publik</SelectItem>
                                      <SelectItem value="restricted">Terbatas</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                              </div>
                            )}
                            <DialogFooter className="gap-2">
                              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                                Batal
                              </Button>
                              <Button
                                onClick={handleEditHealthData}
                                className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800"
                              >
                                Simpan Perubahan
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>

                        {/* Delete Dialog */}
                        <Dialog
                          open={isDeleteDialogOpen && currentData?.id === item.id}
                          onOpenChange={(open) => {
                            setIsDeleteDialogOpen(open)
                            if (!open) setCurrentData(null)
                          }}
                        >
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="icon"
                              className="hover:bg-red-50 hover:border-red-200 hover:text-red-600 dark:hover:bg-red-900/20"
                              onClick={() => setCurrentData(item)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle className="text-xl font-semibold">Hapus Data Kesehatan</DialogTitle>
                              <DialogDescription>
                                Apakah Anda yakin ingin menghapus data kesehatan "{item.title}"? Tindakan ini tidak
                                dapat dibatalkan.
                              </DialogDescription>
                            </DialogHeader>
                            <DialogFooter className="gap-2">
                              <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                                Batal
                              </Button>
                              <Button variant="destructive" onClick={handleDeleteHealthData}>
                                Hapus Data
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-12">
                    <div className="flex flex-col items-center space-y-3">
                      <Database className="h-12 w-12 text-gray-400" />
                      <div>
                        <p className="text-gray-500 dark:text-gray-400 font-medium">
                          Tidak ada data kesehatan yang ditemukan
                        </p>
                        <p className="text-sm text-gray-400 dark:text-gray-500">
                          Mulai dengan menambahkan data kesehatan pertama Anda
                        </p>
                      </div>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

export default HealthDataPage
