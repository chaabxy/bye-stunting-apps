import { type NextRequest, NextResponse } from "next/server";

// Data dummy artikel yang konsisten
const articles = [
  {
    id: 1,
    title: "Memahami Stunting dan Dampaknya pada Anak",
    excerpt:
      "Stunting adalah kondisi gagal tumbuh pada anak akibat kekurangan gizi kronis. Ketahui dampak jangka panjangnya pada perkembangan anak.",
    content: `
      <h2>Apa itu Stunting?</h2>
      <p>Stunting adalah kondisi gagal tumbuh pada anak yang disebabkan oleh kekurangan gizi kronis, terutama dalam 1000 hari pertama kehidupan. Kondisi ini ditandai dengan tinggi badan anak yang berada di bawah standar WHO untuk usianya.</p>
      
      <h2>Penyebab Stunting</h2>
      <p>Beberapa faktor yang menyebabkan stunting antara lain kurangnya asupan gizi selama kehamilan, pemberian ASI yang tidak optimal, sanitasi yang buruk, dan infeksi berulang pada anak.</p>
      
      <h2>Dampak Jangka Panjang</h2>
      <p>Stunting tidak hanya mempengaruhi pertumbuhan fisik, tetapi juga perkembangan kognitif anak. Anak yang mengalami stunting berisiko memiliki kemampuan belajar yang terbatas dan produktivitas yang rendah di masa dewasa.</p>
    `,
    image: "/placeholder.svg?height=400&width=600",
    date: "15 Januari 2024",
    category: "Pengetahuan Umum",
    likes: 45,
    views: 1250,
    isPopular: true,
    tableOfContents: [
      "Apa itu Stunting?",
      "Penyebab Stunting",
      "Dampak Jangka Panjang",
      "Kesimpulan",
    ],
    importantPoints: [
      "Stunting terjadi dalam 1000 hari pertama kehidupan",
      "Mempengaruhi pertumbuhan fisik dan kognitif",
      "Dapat dicegah dengan gizi yang tepat",
      "Dampak berlangsung hingga dewasa",
    ],
  },
  {
    id: 2,
    title: "Nutrisi Penting untuk Mencegah Stunting",
    excerpt:
      "Pelajari nutrisi-nutrisi penting yang harus diberikan pada anak untuk mencegah stunting dan mendukung pertumbuhan optimal.",
    content: `
      <h2>Protein untuk Pertumbuhan</h2>
      <p>Protein merupakan zat gizi yang sangat penting untuk pertumbuhan anak. Sumber protein yang baik antara lain daging, ikan, telur, dan kacang-kacangan.</p>
      
      <h2>Vitamin dan Mineral Esensial</h2>
      <p>Vitamin A, D, dan zat besi sangat penting untuk mencegah stunting. Pastikan anak mendapat asupan yang cukup dari makanan bergizi atau suplemen jika diperlukan.</p>
      
      <h2>ASI Eksklusif</h2>
      <p>ASI eksklusif selama 6 bulan pertama memberikan nutrisi terbaik untuk bayi dan membantu mencegah stunting.</p>
    `,
    image: "/placeholder.svg?height=400&width=600",
    date: "12 Januari 2024",
    category: "Nutrisi",
    likes: 32,
    views: 890,
    isPopular: true,
    tableOfContents: [
      "Protein untuk Pertumbuhan",
      "Vitamin dan Mineral Esensial",
      "ASI Eksklusif",
      "Kesimpulan",
    ],
    importantPoints: [
      "Protein penting untuk pertumbuhan otot dan tulang",
      "Vitamin A mendukung sistem imun",
      "Zat besi mencegah anemia",
      "ASI eksklusif 6 bulan pertama",
    ],
  },
  {
    id: 3,
    title: "Resep MPASI Bergizi untuk Bayi 6-12 Bulan",
    excerpt:
      "Kumpulan resep MPASI bergizi yang mudah dibuat dan aman untuk bayi usia 6-12 bulan sebagai makanan pendamping ASI.",
    content: `
      <h2>Bubur Ayam Wortel</h2>
      <p>Resep bubur ayam wortel yang kaya protein dan vitamin A. Cocok untuk bayi usia 6-8 bulan sebagai MPASI pertama.</p>
      
      <h2>Pure Alpukat Pisang</h2>
      <p>Kombinasi alpukat dan pisang memberikan lemak sehat dan energi yang dibutuhkan bayi untuk pertumbuhan optimal.</p>
      
      <h2>Tim Ikan Salmon</h2>
      <p>Ikan salmon kaya omega-3 yang baik untuk perkembangan otak bayi. Olah dengan cara dikukus untuk mempertahankan nutrisi.</p>
    `,
    image: "/placeholder.svg?height=400&width=600",
    date: "10 Januari 2024",
    category: "Resep Makanan",
    likes: 28,
    views: 756,
    isPopular: false,
    tableOfContents: [
      "Bubur Ayam Wortel",
      "Pure Alpukat Pisang",
      "Tim Ikan Salmon",
      "Kesimpulan",
    ],
    importantPoints: [
      "Mulai MPASI di usia 6 bulan",
      "Perkenalkan satu jenis makanan dulu",
      "Pastikan tekstur sesuai usia",
      "Jaga kebersihan saat memasak",
    ],
  },
];

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");

    let filteredArticles = [...articles];

    if (category && category !== "all") {
      filteredArticles = articles.filter(
        (article) => article.category.toLowerCase() === category.toLowerCase()
      );
    }

    return NextResponse.json(filteredArticles);
  } catch (error) {
    console.error("Error fetching articles:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const newArticle = {
      id: articles.length + 1,
      ...body,
      likes: 0,
      views: 0,
      isPopular: false,
      date: new Date().toLocaleDateString("id-ID", {
        day: "numeric",
        month: "long",
        year: "numeric",
      }),
    };

    articles.push(newArticle);

    return NextResponse.json(newArticle, { status: 201 });
  } catch (error) {
    console.error("Error creating article:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
